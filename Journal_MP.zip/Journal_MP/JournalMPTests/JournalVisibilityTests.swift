import XCTest
import SwiftData
@testable import JournalMP

final class IdentityTokenTests: XCTestCase {
    func testReadsNameFromGoogleToken() {
        let payload = #"{"sub":"123","name":"Aaradhana"}"#
        let encoded = Data(payload.utf8).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
        let token = "header.\(encoded).signature"
        XCTAssertEqual(IdentityToken.claim("name", in: token), "Aaradhana")
        XCTAssertEqual(IdentityToken.claim("sub", in: token), "123")
    }
}

final class StoryYearTests: XCTestCase {
    func testYearPortraitSkipsPrivateEntries() {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let september = calendar.date(from: DateComponents(year: 2026, month: 9, day: 3))!
        let entries = [
            StorySource(date: september, title: "Today", content: "one two three four", isPrivate: false),
            StorySource(date: september, title: "Secret", content: "hidden words", isPrivate: true)
        ]
        let portrait = StoryYear.portrait(year: 2026, entries: entries, memories: [september, september], calendar: calendar)
        XCTAssertEqual(portrait.entries, 1)
        XCTAssertEqual(portrait.words, 5)
        XCTAssertEqual(portrait.memories, 2)
        XCTAssertEqual(portrait.months.count, 1)
        XCTAssertEqual(StoryYear.wordsLabel(8400), "8.4k words")
        XCTAssertEqual(StoryYear.entriesLabel(24), "24 entries")
        XCTAssertEqual(StoryYear.memoriesLabel(31), "31 memories")
    }
}

final class MoodMemoryTests: XCTestCase {
    func testMonthRemembersMoodsAndFavorites() {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let september = calendar.date(from: DateComponents(year: 2026, month: 9, day: 15))!
        let notes = [
            MemoryNote(date: calendar.date(from: DateComponents(year: 2026, month: 9, day: 1, hour: 9))!, mood: "Happy", isFavorite: false),
            MemoryNote(date: calendar.date(from: DateComponents(year: 2026, month: 9, day: 2, hour: 9))!, mood: "Calm", isFavorite: false),
            MemoryNote(date: calendar.date(from: DateComponents(year: 2026, month: 9, day: 3, hour: 9))!, mood: "Happy", isFavorite: false),
            MemoryNote(date: calendar.date(from: DateComponents(year: 2026, month: 9, day: 4, hour: 9))!, mood: nil, isFavorite: true),
            MemoryNote(date: calendar.date(from: DateComponents(year: 2026, month: 9, day: 8, hour: 9))!, mood: "Overwhelmed", isFavorite: false)
        ]
        let marks = MoodMemory.marks(in: september, from: notes, calendar: MoodMemory.mondayCalendar(calendar))
        let byDay = Dictionary(uniqueKeysWithValues: marks.map { (calendar.component(.day, from: $0.day), $0.symbol) })
        XCTAssertEqual(byDay[1], "😊")
        XCTAssertEqual(byDay[2], "😌")
        XCTAssertEqual(byDay[4], "❤️")
        XCTAssertEqual(MoodMemory.notes(in: september, from: notes, calendar: calendar).count, 5)
        XCTAssertEqual(MoodMemory.topMoods(in: september, from: notes, calendar: calendar).map(\.mood.rawValue), ["Happy", "Calm", "Overwhelmed"])
    }
}

final class SearchHighlightTests: XCTestCase {
    func testQueryFindsAndFocusesTheMatch() {
        let content = "Morning notes\nI do want to remember this."
        let ranges = SearchHighlight.ranges(in: content, query: "do")
        XCTAssertEqual(ranges.count, 1)
        XCTAssertEqual(String(content[ranges[0]]), "do")
        XCTAssertEqual(
            SearchHighlight.focus(title: "A quiet day", content: content, query: "do"),
            .paragraph(1)
        )
        XCTAssertEqual(
            SearchHighlight.focus(title: "What I do", content: content, query: "do"),
            .title
        )
    }
}

final class TalkLanguageTests: XCTestCase {
    func testTalkIsEnglishOnly() {
        XCTAssertEqual(TalkLanguageCatalog.all.map(\.code), ["en"])
        XCTAssertEqual(TalkLanguageCatalog.activationOrder(preferredCode: "ta").map(\.code), ["en"])
        XCTAssertEqual(TalkLanguageCatalog.preferredCode(deviceLanguageCode: "ta", remembered: "hi"), "en")
        XCTAssertNil(TalkLanguageCatalog.detect(in: "இன்று நாள் நன்றாக இருந்தது"))
        XCTAssertNil(TalkLanguageCatalog.detect(in: "आज का दिन काफ़ी अच्छा रहा"))
        XCTAssertTrue(TalkLanguageCatalog.romanizedGuesses(in: "Unakku enna venamo solla jab hum dekhte hai").isEmpty)
    }

    func testEnglishStaysEnglish() {
        XCTAssertEqual(
            TalkLanguageCatalog.detect(in: "Today was actually quite interesting and full of small surprises")?.code,
            "en"
        )
    }
}

final class DictationTranscriptTests: XCTestCase {
    func testLiveSpeechAppearsInTheEditor() {
        var finalized = ""
        var volatile = ""
        DictationTranscript.absorb(finalized: &finalized, volatile: &volatile, text: "Today was actually", isFinal: false)
        let live = DictationTranscript.join(
            base: "",
            spoken: DictationTranscript.spoken(finalized: finalized, volatile: volatile)
        )
        XCTAssertEqual(live, "Today was actually")

        DictationTranscript.absorb(finalized: &finalized, volatile: &volatile, text: "Today was actually quite interesting", isFinal: true)
        let saved = DictationTranscript.join(
            base: "",
            spoken: DictationTranscript.spoken(finalized: finalized, volatile: volatile)
        )
        XCTAssertEqual(saved, "Today was actually quite interesting")
        XCTAssertEqual(volatile, "")
    }
}

final class JournalVisibilityTests: XCTestCase {
    private let secret = "hidden-journal-line-4821"
    private let visible = "A visible morning"

    private var mixed: [VisibleEntry] {
        [
            VisibleEntry(
                title: "Kept",
                content: secret,
                createdAt: Date(timeIntervalSince1970: 200),
                mood: "Heavy",
                isFavorite: true,
                isPrivate: true
            ),
            VisibleEntry(
                title: "Today",
                content: visible,
                createdAt: Date(timeIntervalSince1970: 100),
                mood: "Peaceful",
                isFavorite: false,
                isPrivate: false
            )
        ]
    }

    func testSearchOmitsPrivateEntries() {
        let results = JournalVisibility.search(mixed, query: "journal")
        XCTAssertTrue(results.isEmpty)
        let found = JournalVisibility.search(mixed, query: "visible")
        XCTAssertEqual(found.map(\.content), [visible])
    }

    func testWidgetSnapshotOmitsPrivateText() throws {
        let snapshot = JournalVisibility.widgetSnapshot(from: mixed, prompt: DailyPrompt.prompts[0])
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        let json = String(decoding: try encoder.encode(snapshot), as: UTF8.self)
        XCTAssertFalse(json.contains(secret))
        XCTAssertTrue(json.contains(visible))
        XCTAssertEqual(snapshot.title, "Today")
    }

    func testPrivateOnlySnapshotHasNoExcerpt() throws {
        let snapshot = JournalVisibility.widgetSnapshot(
            from: mixed.filter(\.isPrivate),
            prompt: "What made you smile today?"
        )
        XCTAssertEqual(snapshot.excerpt, "")
        let encoder = JSONEncoder()
        let json = String(decoding: try encoder.encode(snapshot), as: UTF8.self)
        XCTAssertFalse(json.contains(secret))
    }

    func testExportOmitsPrivateEntries() {
        let export = JournalVisibility.exportText(from: mixed)
        XCTAssertFalse(export.contains(secret))
        XCTAssertTrue(export.contains(visible))
    }

    func testReminderCopyHasNoEntryText() {
        XCTAssertFalse(ReminderCopy.body.contains(secret))
        XCTAssertFalse(ReminderCopy.title.contains(secret))
        XCTAssertEqual(ReminderCopy.body, "A quiet moment to write.")
    }

    func testLockPolicyIncludesPasscodeFallback() {
        XCTAssertEqual(BiometricLock.policy, .deviceOwnerAuthentication)
    }
}

@MainActor
final class JournalStoreTests: XCTestCase {
    func testPublicFetchExcludesPrivateEntries() throws {
        let configuration = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: JournalEntry.self, configurations: configuration)
        let context = container.mainContext
        context.insert(JournalEntry(title: "Day", content: "Visible thought"))
        context.insert(JournalEntry(title: "Secret", content: "Hidden thought", isPrivate: true))
        try context.save()

        let descriptor = FetchDescriptor<JournalEntry>(
            predicate: #Predicate { $0.isPrivate == false }
        )
        let results = try context.fetch(descriptor)
        XCTAssertEqual(results.map(\.content), ["Visible thought"])

        let snapshot = JournalVisibility.widgetSnapshot(
            from: [JournalLibrary.latestPublicEntry(in: context)!.visible],
            prompt: "Prompt"
        )
        XCTAssertFalse(snapshot.excerpt.contains("Hidden"))
        XCTAssertTrue(snapshot.excerpt.contains("Visible"))
    }

    func testMarkingPrivateRemovesEntryFromPublicSnapshot() throws {
        let configuration = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: JournalEntry.self, configurations: configuration)
        let context = container.mainContext
        let entry = JournalEntry(title: "Later", content: "Move me")
        context.insert(entry)
        let other = JournalEntry(title: "Stay", content: "Public line")
        context.insert(other)
        try context.save()

        try JournalLibrary.setPrivate(entry, true, in: context)
        let latest = try XCTUnwrap(JournalLibrary.latestPublicEntry(in: context))
        XCTAssertEqual(latest.content, "Public line")
        XCTAssertTrue(entry.isPrivate)
    }
}
