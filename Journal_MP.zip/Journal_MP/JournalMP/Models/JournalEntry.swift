import Foundation
import SwiftData

@Model
final class JournalEntry {
    var id: UUID
    var title: String
    var content: String
    var createdAt: Date
    var updatedAt: Date
    var mood: String?
    var isFavorite: Bool
    var isPrivate: Bool

    init(
        title: String = "",
        content: String = "",
        mood: String? = nil,
        isPrivate: Bool = false
    ) {
        self.id = UUID()
        self.title = title
        self.content = content
        self.createdAt = .now
        self.updatedAt = .now
        self.mood = mood
        self.isFavorite = false
        self.isPrivate = isPrivate
    }

    var visible: VisibleEntry {
        VisibleEntry(
            title: title,
            content: content,
            createdAt: createdAt,
            mood: mood,
            isFavorite: isFavorite,
            isPrivate: isPrivate
        )
    }
}
