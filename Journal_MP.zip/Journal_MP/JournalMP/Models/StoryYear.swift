import Foundation

struct StorySource: Equatable {
    var date: Date
    var title: String
    var content: String
    var isPrivate: Bool
}

enum StoryYear {
    struct Portrait: Equatable {
        var entries: Int
        var words: Int
        var memories: Int
        var months: [Date]
    }

    static func portrait(year: Int, entries: [StorySource], memories: [Date], calendar: Calendar = .current) -> Portrait {
        let visible = entries.filter { !$0.isPrivate && calendar.component(.year, from: $0.date) == year }
        let months = Set(visible.map { monthStart($0.date, calendar: calendar) })
        let memoryCount = memories.filter { calendar.component(.year, from: $0) == year }.count
        return Portrait(
            entries: visible.count,
            words: visible.reduce(0) { $0 + wordCount($1.title) + wordCount($1.content) },
            memories: memoryCount,
            months: months.sorted(by: >)
        )
    }

    static func wordCount(_ text: String) -> Int {
        text.split { $0.isWhitespace || $0.isNewline }.filter { !$0.isEmpty }.count
    }

    static func wordsLabel(_ words: Int) -> String {
        guard words >= 1000 else { return "\(words) words" }
        let thousands = Double(words) / 1000
        if thousands == thousands.rounded() {
            return "\(Int(thousands))k words"
        }
        return String(format: "%.1fk words", thousands)
    }

    static func entriesLabel(_ count: Int) -> String {
        count == 1 ? "1 entry" : "\(count) entries"
    }

    static func memoriesLabel(_ count: Int) -> String {
        count == 1 ? "1 memory" : "\(count) memories"
    }

    private static func monthStart(_ date: Date, calendar: Calendar) -> Date {
        let parts = calendar.dateComponents([.year, .month], from: date)
        return calendar.date(from: parts) ?? date
    }
}
