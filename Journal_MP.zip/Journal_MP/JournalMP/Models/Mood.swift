import Foundation

enum Mood: String, CaseIterable, Identifiable {
    case happy = "Happy"
    case calm = "Calm"
    case steady = "Steady"
    case heavy = "Heavy"
    case overwhelmed = "Overwhelmed"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .happy: "😊"
        case .calm: "😌"
        case .steady: "😐"
        case .heavy: "😔"
        case .overwhelmed: "😵"
        }
    }

    static func resolved(_ stored: String?) -> Mood? {
        guard let stored else { return nil }
        let trimmed = stored.trimmingCharacters(in: .whitespacesAndNewlines)
        if let mood = Mood(rawValue: trimmed) { return mood }
        switch trimmed {
        case "Joyful": return .happy
        case "Peaceful": return .calm
        case "Stormy": return .overwhelmed
        default: return nil
        }
    }
}
