import Foundation
import SwiftData

enum StoryShelf: String, CaseIterable, Identifiable {
    case chapter = "Chapters"
    case person = "People"
    case place = "Places"
    case loved = "Things I loved"
    case learned = "Things I learned"
    case letter = "Letters to Future Me"

    var id: String { rawValue }

    var prompt: String {
        switch self {
        case .chapter: "Name a chapter"
        case .person: "Someone who belongs here"
        case .place: "A place you remember"
        case .loved: "Something you loved"
        case .learned: "Something you learned"
        case .letter: "A letter to your future self"
        }
    }
}

@Model
final class StoryPiece {
    var id: UUID
    var shelf: String
    var title: String
    var body: String
    var createdAt: Date
    var updatedAt: Date

    init(shelf: StoryShelf, title: String = "", body: String = "") {
        self.id = UUID()
        self.shelf = shelf.rawValue
        self.title = title
        self.body = body
        self.createdAt = .now
        self.updatedAt = .now
    }

    var kind: StoryShelf {
        StoryShelf(rawValue: shelf) ?? .chapter
    }
}
