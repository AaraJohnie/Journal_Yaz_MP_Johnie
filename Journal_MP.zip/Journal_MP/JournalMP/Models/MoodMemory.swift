import Foundation

struct MemoryNote: Equatable {
    var date: Date
    var mood: String?
    var isFavorite: Bool
}

enum MoodMemory {
    struct DayMark: Equatable, Identifiable {
        var day: Date
        var symbol: String?
        var label: String
        var id: Date { day }
    }

    struct MoodCount: Equatable, Identifiable {
        var mood: Mood
        var count: Int
        var id: String { mood.rawValue }
    }

    static func symbol(mood: String?, isFavorite: Bool) -> String? {
        if let mood = Mood.resolved(mood) { return mood.symbol }
        if isFavorite { return "❤️" }
        return nil
    }

    static func monthInterval(_ month: Date, calendar: Calendar = .current) -> DateInterval? {
        calendar.dateInterval(of: .month, for: month)
    }

    static func notes(in month: Date, from source: [MemoryNote], calendar: Calendar = .current) -> [MemoryNote] {
        guard let interval = monthInterval(month, calendar: calendar) else { return [] }
        return source.filter { interval.contains($0.date) }
    }

    static func marks(in month: Date, from source: [MemoryNote], calendar: Calendar = .current) -> [DayMark] {
        let calendar = mondayCalendar(calendar)
        guard let interval = monthInterval(month, calendar: calendar) else { return [] }
        let grouped = Dictionary(grouping: notes(in: month, from: source, calendar: calendar)) {
            calendar.startOfDay(for: $0.date)
        }
        var days: [DayMark] = []
        var cursor = interval.start
        while cursor < interval.end {
            let day = calendar.startOfDay(for: cursor)
            let latest = grouped[day]?.max { $0.date < $1.date }
            let symbol = latest.flatMap { symbol(mood: $0.mood, isFavorite: $0.isFavorite) }
            let label = day.formatted(.dateTime.weekday(.wide).month(.wide).day())
            days.append(DayMark(day: day, symbol: symbol, label: label))
            guard let next = calendar.date(byAdding: .day, value: 1, to: cursor) else { break }
            cursor = next
        }
        return days
    }

    static func leadingBlanks(in month: Date, calendar: Calendar = mondayCalendar(.current)) -> Int {
        guard let start = monthInterval(month, calendar: calendar)?.start else { return 0 }
        let weekday = calendar.component(.weekday, from: start)
        let first = calendar.firstWeekday
        return (weekday - first + 7) % 7
    }

    static func topMoods(in month: Date, from source: [MemoryNote], limit: Int = 3, calendar: Calendar = .current) -> [MoodCount] {
        var counts: [Mood: Int] = [:]
        for note in notes(in: month, from: source, calendar: calendar) {
            guard let mood = Mood.resolved(note.mood) else { continue }
            counts[mood, default: 0] += 1
        }
        return counts
            .map { MoodCount(mood: $0.key, count: $0.value) }
            .sorted {
                if $0.count != $1.count { return $0.count > $1.count }
                return $0.mood.rawValue < $1.mood.rawValue
            }
            .prefix(limit)
            .map { $0 }
    }

    static func mondayCalendar(_ calendar: Calendar) -> Calendar {
        var copy = calendar
        copy.firstWeekday = 2
        return copy
    }
}
