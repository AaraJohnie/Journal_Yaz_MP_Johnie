import SwiftUI
import SwiftData

@main
struct JournalMPApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(JournalStore.container)
    }
}
