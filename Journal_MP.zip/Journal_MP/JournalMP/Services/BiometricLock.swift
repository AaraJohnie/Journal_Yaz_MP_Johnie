import Foundation
import LocalAuthentication

enum BiometricLock {
    /// Face ID or Touch ID, with the device passcode as fallback.
    static let policy: LAPolicy = .deviceOwnerAuthentication

    struct Availability {
        var isReady: Bool
        var method: String
        var detail: String
    }

    static func availability() -> Availability {
        let context = LAContext()
        var error: NSError?
        let ready = context.canEvaluatePolicy(policy, error: &error)
        let method = biometryName(context.biometryType)
        if ready {
            return Availability(
                isReady: true,
                method: method,
                detail: "\(method), or your device passcode"
            )
        }
        return Availability(
            isReady: false,
            method: method,
            detail: error?.localizedDescription ?? "Set a device passcode to lock Private."
        )
    }

    static func unlock() async -> Bool {
        let context = LAContext()
        context.localizedCancelTitle = "Not Now"
        var error: NSError?
        guard context.canEvaluatePolicy(policy, error: &error) else { return false }
        do {
            return try await context.evaluatePolicy(policy, localizedReason: "Unlock your private journal.")
        } catch {
            return false
        }
    }

    private static func biometryName(_ type: LABiometryType) -> String {
        switch type {
        case .faceID: "Face ID"
        case .touchID: "Touch ID"
        case .opticID: "Optic ID"
        default: "Biometrics"
        }
    }
}
