import Foundation
import SwiftData

enum JournalStore {
    static let container: ModelContainer = {
        let schema = Schema([JournalEntry.self, StoryPiece.self])
        let configuration = ModelConfiguration(
            "Journal",
            schema: schema,
            isStoredInMemoryOnly: false,
            allowsSave: true,
            groupContainer: .none,
            cloudKitDatabase: .none
        )
        do {
            return try ModelContainer(for: schema, configurations: configuration)
        } catch {
            fatalError("Unable to open the local journal store: \(error)")
        }
    }()

    @MainActor
    static var previewContainer: ModelContainer = {
        let configuration = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try! ModelContainer(for: JournalEntry.self, StoryPiece.self, configurations: configuration)
        let context = container.mainContext
        context.insert(
            JournalEntry(
                title: "A quiet evening",
                content: "Today felt different, in a way I want to remember.",
                mood: Mood.calm.rawValue
            )
        )
        context.insert(
            JournalEntry(
                title: "Kept aside",
                content: "This line belongs only in Private.",
                isPrivate: true
            )
        )
        return container
    }()
}
