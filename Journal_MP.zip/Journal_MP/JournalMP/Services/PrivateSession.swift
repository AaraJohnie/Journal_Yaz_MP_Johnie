import Foundation

@Observable
final class PrivateSession {
    var isUnlocked = false

    func lock() {
        isUnlocked = false
    }
}
