import Foundation
import NaturalLanguage

struct TalkLanguage: Equatable, Sendable {
    let code: String
    let name: String
    let localeIdentifiers: [String]
    let nl: NLLanguage
    let script: TalkScript
}

struct RomanizedGuess: Equatable, Sendable {
    let code: String
    let hits: Int
}

struct TalkFragment: Equatable, Sendable {
    var text: String
    var start: Double
    var end: Double
}

enum TalkScript: Equatable, Sendable {
    case latin
    case han
    case devanagari
    case arabic
    case bengali
    case cyrillic
    case tamil
}

struct ResolvedTalkLanguage: Equatable, Sendable {
    let language: TalkLanguage
    let locale: Locale
}

enum TalkLanguageCatalog {
    static let memoryKey = "talkLanguageID"

    static let all: [TalkLanguage] = [
        TalkLanguage(code: "en", name: "English", localeIdentifiers: ["en-IN", "en-US", "en-GB", "en"], nl: .english, script: .latin)
    ]

    static func language(code: String) -> TalkLanguage? {
        all.first { $0.code == code }
    }

    static func language(matching locale: Locale) -> TalkLanguage {
        let code = locale.language.languageCode?.identifier
        if let code, let match = language(code: code) {
            return match
        }
        return language(code: "en") ?? all[0]
    }

    static func preferredCode(deviceLanguageCode _: String?, remembered _: String?) -> String {
        "en"
    }

    static func activationOrder(preferredCode _: String) -> [TalkLanguage] {
        all
    }

    /// How well this transcript belongs to one talk language. Used to choose among live recognizers.
    static func recognitionScore(text: String, language: TalkLanguage, confidence: Double?) -> Double {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else { return 0 }
        let base = confidence ?? 0.4
        switch dominantScript(in: trimmed, latinMinimum: 4) {
        case language.script:
            break
        case nil:
            return base
        default:
            return min(base, 0.15)
        }
        var score = base + 0.3
        if let detected = detect(in: trimmed), detected.code == language.code {
            score += 0.45
        }
        return score
    }

    /// Latin spelling of speech that was not English, such as “unakku enna” or “jab hum dekhte hai”.
    static func romanizedGuesses(in text: String) -> [RomanizedGuess] {
        let tokens = romanizedTokens(in: text)
        guard tokens.count >= 3 else { return [] }
        var guesses: [RomanizedGuess] = []
        for (code, words) in romanizedLexicon {
            let hits = tokens.reduce(into: 0) { count, token in
                if words.contains(token) { count += 1 }
            }
            let share = Double(hits) / Double(tokens.count)
            let matched = (hits >= 2 && share >= 0.34) || (hits >= 3 && share >= 0.08)
            if matched {
                guesses.append(RomanizedGuess(code: code, hits: hits))
            }
        }
        return guesses.sorted { lhs, rhs in
            if lhs.hits == rhs.hits { return lhs.code < rhs.code }
            return lhs.hits > rhs.hits
        }
    }

    static func rewrittenText(passes: [(code: String, fragments: [TalkFragment])]) -> String {
        var kept: [(start: Double, end: Double, text: String)] = []
        for pass in passes {
            guard let language = language(code: pass.code) else { continue }
            for fragment in pass.fragments {
                let text = fragment.text.trimmingCharacters(in: .whitespacesAndNewlines)
                guard text.count >= 2 else { continue }
                guard dominantScript(in: text, latinMinimum: 2) == language.script else { continue }
                kept.append((fragment.start, max(fragment.end, fragment.start), text))
            }
        }
        kept.sort { lhs, rhs in
            if lhs.start == rhs.start { return (lhs.end - lhs.start) < (rhs.end - rhs.start) }
            return lhs.start < rhs.start
        }
        var chosen: [(start: Double, end: Double, text: String)] = []
        for item in kept {
            if let last = chosen.last, item.start < last.end - 0.15 {
                let lastSpan = last.end - last.start
                let itemSpan = item.end - item.start
                if itemSpan + 0.2 < lastSpan {
                    chosen.removeLast()
                    chosen.append(item)
                }
                continue
            }
            chosen.append(item)
        }
        return chosen.map(\.text).joined(separator: " ")
    }

    static func isNativeRewrite(_ rewritten: String, replacing original: String) -> Bool {
        let rewrittenScript = dominantScript(in: rewritten, latinMinimum: 2)
        guard let rewrittenScript, rewrittenScript != .latin else { return false }
        let originalScript = dominantScript(in: original, latinMinimum: 2)
        return originalScript == nil || originalScript == .latin
    }

    static func remember(_ code: String) {
        guard language(code: code) != nil else { return }
        UserDefaults.standard.set(code, forKey: memoryKey)
    }

    /// Reads a transcript that is already in the right script and picks one talk language.
    static func detect(in text: String) -> TalkLanguage? {
        guard dominantScript(in: text) == .latin else { return nil }
        guard let found = latinDetection(in: text), found.probability >= 0.34 else { return nil }
        return language(code: found.code)
    }

    static func latinDetection(in text: String) -> (code: String, probability: Double)? {
        guard dominantScript(in: text) == .latin else { return nil }
        let hypotheses = hypotheses(in: text, constrainedTo: [.english])
        guard let probability = hypotheses[.english], probability >= 0.34 else { return nil }
        return ("en", probability)
    }

    static func dominantScript(in text: String, latinMinimum: Int = 8) -> TalkScript? {
        var counts: [TalkScript: Int] = [:]
        for scalar in text.unicodeScalars {
            guard let script = script(of: scalar) else { continue }
            counts[script, default: 0] += 1
        }
        let written = counts.filter { $0.key != .latin && $0.value >= 2 }
        if let best = written.max(by: { $0.value < $1.value }) {
            return best.key
        }
        if (counts[.latin] ?? 0) >= latinMinimum {
            return .latin
        }
        return nil
    }

    private static func hypotheses(in text: String, constrainedTo languages: [NLLanguage]) -> [NLLanguage: Double] {
        let recognizer = NLLanguageRecognizer()
        recognizer.languageConstraints = languages
        recognizer.processString(text)
        return recognizer.languageHypotheses(withMaximum: languages.count)
    }

    private static func romanizedTokens(in text: String) -> [String] {
        text.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { $0.count >= 2 }
    }

    private static let romanizedLexicon: [String: Set<String>] = [:]

    private static func script(of scalar: Unicode.Scalar) -> TalkScript? {
        switch scalar.value {
        case 0x0400...0x04FF, 0x0500...0x052F:
            return .cyrillic
        case 0x0600...0x06FF, 0x0750...0x077F, 0x08A0...0x08FF:
            return .arabic
        case 0x0900...0x097F:
            return .devanagari
        case 0x0980...0x09FF:
            return .bengali
        case 0x0B80...0x0BFF:
            return .tamil
        case 0x3400...0x4DBF, 0x4E00...0x9FFF:
            return .han
        default:
            return CharacterSet.letters.contains(scalar) ? .latin : nil
        }
    }
}
