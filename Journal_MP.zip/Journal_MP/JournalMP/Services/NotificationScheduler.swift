import Foundation
import UserNotifications

enum NotificationScheduler {
    static func schedule(at time: Date) async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            let granted = (try? await center.requestAuthorization(options: [.alert, .sound])) ?? false
            guard granted else { return }
        } else if settings.authorizationStatus != .authorized && settings.authorizationStatus != .provisional {
            return
        }

        center.removePendingNotificationRequests(withIdentifiers: [ReminderCopy.identifier])
        let components = Calendar.current.dateComponents([.hour, .minute], from: time)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        let content = UNMutableNotificationContent()
        content.title = ReminderCopy.title
        content.body = ReminderCopy.body
        content.sound = .default
        let request = UNNotificationRequest(identifier: ReminderCopy.identifier, content: content, trigger: trigger)
        try? await center.add(request)
    }

    static func cancel() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [ReminderCopy.identifier])
    }
}
