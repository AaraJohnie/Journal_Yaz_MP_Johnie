import AuthenticationServices
import Foundation
import UIKit

struct AccountProfile: Equatable {
    var userID: String
    var name: String?
    var provider: String
}

enum AccountStore {
    static let signedInKey = "isSignedIn"
    static let providerKey = "authProvider"
    static let userIDKey = "authUserID"

    static func save(_ profile: AccountProfile) {
        let defaults = UserDefaults.standard
        defaults.set(true, forKey: signedInKey)
        defaults.set(profile.provider, forKey: providerKey)
        defaults.set(profile.userID, forKey: userIDKey)
        if let name = profile.name?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty {
            defaults.set(name, forKey: "displayName")
        }
    }

    static func signOut() {
        let defaults = UserDefaults.standard
        defaults.set(false, forKey: signedInKey)
        defaults.removeObject(forKey: providerKey)
        defaults.removeObject(forKey: userIDKey)
    }
}

enum AccountError: LocalizedError {
    case cancelled
    case failed
    case googleNotConfigured

    var errorDescription: String? {
        switch self {
        case .cancelled:
            nil
        case .failed:
            "Sign-in didn’t finish. Try again."
        case .googleNotConfigured:
            "Google sign-in needs a client ID in the app before it can open."
        }
    }
}

enum IdentityToken {
    static func claim(_ name: String, in token: String) -> String? {
        let parts = token.split(separator: ".")
        guard parts.count >= 2 else { return nil }
        var payload = String(parts[1])
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = payload.count % 4
        if remainder != 0 {
            payload += String(repeating: "=", count: 4 - remainder)
        }
        guard let data = Data(base64Encoded: payload),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        return json[name] as? String
    }
}

@MainActor
enum AccountSession {
    static func signInWithApple() async throws -> AccountProfile {
        try await withCheckedThrowingContinuation { continuation in
            let coordinator = AppleSignInCoordinator(continuation: continuation)
            retain(coordinator)
            let request = ASAuthorizationAppleIDProvider().createRequest()
            request.requestedScopes = [.fullName, .email]
            let controller = ASAuthorizationController(authorizationRequests: [request])
            controller.delegate = coordinator
            controller.presentationContextProvider = coordinator
            controller.performRequests()
        }
    }

    static func signInWithGoogle() async throws -> AccountProfile {
        guard let clientID = Bundle.main.object(forInfoDictionaryKey: "GIDClientID") as? String,
              !clientID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AccountError.googleNotConfigured
        }
        var components = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "redirect_uri", value: "com.journalmp.app:/oauth2redirect"),
            URLQueryItem(name: "response_type", value: "id_token"),
            URLQueryItem(name: "scope", value: "openid email profile"),
            URLQueryItem(name: "nonce", value: UUID().uuidString)
        ]
        guard let url = components.url else { throw AccountError.failed }
        return try await withCheckedThrowingContinuation { continuation in
            let coordinator = GoogleSignInCoordinator(continuation: continuation)
            retain(coordinator)
            let session = ASWebAuthenticationSession(url: url, callbackURLScheme: "com.journalmp.app") { callback, error in
                coordinator.finish(callback: callback, error: error)
            }
            session.presentationContextProvider = coordinator
            session.prefersEphemeralWebBrowserSession = false
            coordinator.session = session
            if !session.start() {
                release(coordinator)
                continuation.resume(throwing: AccountError.failed)
            }
        }
    }

    private static var retained: [ObjectIdentifier: AnyObject] = [:]

    static func retain(_ object: AnyObject) {
        retained[ObjectIdentifier(object)] = object
    }

    static func release(_ object: AnyObject) {
        retained[ObjectIdentifier(object)] = nil
    }
}

private final class AppleSignInCoordinator: NSObject, ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
    let continuation: CheckedContinuation<AccountProfile, Error>
    private var resumed = false

    init(continuation: CheckedContinuation<AccountProfile, Error>) {
        self.continuation = continuation
    }

    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        keyWindow()
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        guard !resumed else { return }
        resumed = true
        defer { AccountSession.release(self) }
        guard let credential = authorization.credential as? ASAuthorizationAppleIDCredential else {
            continuation.resume(throwing: AccountError.failed)
            return
        }
        let name = [credential.fullName?.givenName, credential.fullName?.familyName]
            .compactMap { $0 }
            .joined(separator: " ")
        continuation.resume(returning: AccountProfile(
            userID: credential.user,
            name: name.isEmpty ? nil : name,
            provider: "Apple"
        ))
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        guard !resumed else { return }
        resumed = true
        AccountSession.release(self)
        if let authError = error as? ASAuthorizationError, authError.code == .canceled {
            continuation.resume(throwing: AccountError.cancelled)
        } else {
            continuation.resume(throwing: AccountError.failed)
        }
    }
}

private final class GoogleSignInCoordinator: NSObject, ASWebAuthenticationPresentationContextProviding {
    let continuation: CheckedContinuation<AccountProfile, Error>
    var session: ASWebAuthenticationSession?
    private var resumed = false

    init(continuation: CheckedContinuation<AccountProfile, Error>) {
        self.continuation = continuation
    }

    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        keyWindow()
    }

    func finish(callback: URL?, error: Error?) {
        guard !resumed else { return }
        resumed = true
        defer { AccountSession.release(self) }
        if let error = error as? ASWebAuthenticationSessionError, error.code == .canceledLogin {
            continuation.resume(throwing: AccountError.cancelled)
            return
        }
        guard let callback else {
            continuation.resume(throwing: AccountError.failed)
            return
        }
        let token = Self.token(from: callback)
        guard let token, let userID = IdentityToken.claim("sub", in: token) else {
            continuation.resume(throwing: AccountError.failed)
            return
        }
        let name = IdentityToken.claim("name", in: token) ?? IdentityToken.claim("email", in: token)
        continuation.resume(returning: AccountProfile(userID: userID, name: name, provider: "Google"))
    }

    private static func token(from url: URL) -> String? {
        let fragment = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let items = (fragment?.queryItems ?? []) + (fragment?.fragmentItems ?? [])
        return items.first { $0.name == "id_token" }?.value
    }
}

private extension URLComponents {
    var fragmentItems: [URLQueryItem] {
        guard let fragment else { return [] }
        return fragment.split(separator: "&").compactMap { pair in
            let pieces = pair.split(separator: "=", maxSplits: 1).map(String.init)
            guard let name = pieces.first else { return nil }
            return URLQueryItem(name: name, value: pieces.count > 1 ? pieces[1].removingPercentEncoding : nil)
        }
    }
}

private func keyWindow() -> ASPresentationAnchor {
    let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
    return scene?.windows.first { $0.isKeyWindow } ?? scene?.windows.first ?? ASPresentationAnchor()
}
