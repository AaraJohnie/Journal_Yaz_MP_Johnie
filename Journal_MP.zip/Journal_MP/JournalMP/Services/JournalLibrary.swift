import Foundation
import SwiftData
import WidgetKit

@MainActor
enum JournalLibrary {
    static func latestPublicEntry(in context: ModelContext) -> JournalEntry? {
        var descriptor = FetchDescriptor<JournalEntry>(
            predicate: #Predicate { $0.isPrivate == false },
            sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
        )
        descriptor.fetchLimit = 1
        return try? context.fetch(descriptor).first
    }

    static func publish(_ context: ModelContext) {
        let prompt = DailyPrompt.forDate(.now)
        let snapshot: PublicWidgetSnapshot
        if let entry = latestPublicEntry(in: context) {
            snapshot = JournalVisibility.widgetSnapshot(from: [entry.visible], prompt: prompt)
        } else {
            snapshot = JournalVisibility.widgetSnapshot(from: [], prompt: prompt)
        }
        PublicSnapshotStore.save(snapshot)
        WidgetCenter.shared.reloadAllTimelines()
    }

    static func save(_ entry: JournalEntry, in context: ModelContext) throws {
        entry.updatedAt = .now
        if entry.modelContext == nil {
            context.insert(entry)
        }
        try context.save()
        publish(context)
    }

    static func setPrivate(_ entry: JournalEntry, _ isPrivate: Bool, in context: ModelContext) throws {
        entry.isPrivate = isPrivate
        entry.updatedAt = .now
        try context.save()
        publish(context)
    }

    static func delete(_ entry: JournalEntry, in context: ModelContext) throws {
        context.delete(entry)
        try context.save()
        publish(context)
    }
}
