import AVFoundation
import CoreMedia
import Foundation
import Speech

@available(iOS 26, *)
@MainActor
@Observable
final class JournalDictation {
    var isListening = false
    var livePhrase = ""
    var note: String?
    var languageName = ""
    var isPreparingLanguages = false

    private var onSettled: ((String) -> Void)?
    private var onLive: ((String) -> Void)?
    private var analyzer: SpeechAnalyzer?
    private var microphone: MicrophoneFeed?
    private var inputContinuation: AsyncStream<AnalyzerInput>.Continuation?
    private var analysisTask: Task<Void, Never>?
    private var resultTasks: [Task<Void, Never>] = []
    private var commitTask: Task<Void, Never>?
    private var engines: [TalkEngine] = []
    private var lanes: [String: HeardLane] = [:]
    private var committedThrough: Double = 0
    private var preferredCode = "en"
    private var session = 0
    private var voices: [TalkVoice] = []
    private var dictatedText = ""
    private var heardOrder: [String] = []
    private var onRewrite: ((String) -> Void)?

    func begin(
        onSettled: @escaping (String) -> Void,
        onLive: @escaping (String) -> Void,
        onRewrite: @escaping (String) -> Void
    ) async {
        guard !isListening else { return }
        await start(onSettled: onSettled, onLive: onLive, onRewrite: onRewrite)
    }

    func toggle(
        onSettled: @escaping (String) -> Void,
        onLive: @escaping (String) -> Void,
        onRewrite: @escaping (String) -> Void
    ) async {
        if isListening {
            await finishTalking()
        } else {
            await start(onSettled: onSettled, onLive: onLive, onRewrite: onRewrite)
        }
    }

    /// Ends the microphone and lets the last phrase settle into editable text.
    func finishTalking() async {
        commitTask?.cancel()
        commitTask = nil
        guard isListening || microphone != nil || analyzer != nil else { return }
        let feed = microphone
        microphone?.stop()
        microphone = nil
        inputContinuation?.finish()
        inputContinuation = nil
        if let analyzer {
            await finalize(analyzer)
            await analyzer.cancelAndFinishNow()
        }
        isListening = false
        commitRemainder()
        commitTask?.cancel()
        commitTask = nil
        resultTasks.forEach { $0.cancel() }
        resultTasks.removeAll()
        analysisTask?.cancel()
        analysisTask = nil
        analyzer = nil
        engines.removeAll()
        lanes.removeAll()
        livePhrase = ""
        if let snapshot = feed?.snapshot(), !heardOrder.isEmpty {
            let names = heardNames
            note = names.count == 1
                ? "Rewriting that in \(names[0])."
                : "Rewriting that in \(names.joined(separator: " and "))."
            await rewrite(snapshot: snapshot, original: dictatedText)
        }
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    func stop() async {
        await finishTalking()
    }

    private func finalize(_ analyzer: SpeechAnalyzer) async {
        await withTaskGroup(of: Void.self) { group in
            group.addTask {
                try? await analyzer.finalizeAndFinishThroughEndOfInput()
            }
            group.addTask {
                try? await Task.sleep(for: .seconds(1.5))
            }
            await group.next()
            group.cancelAll()
        }
    }

    private func start(
        onSettled: @escaping (String) -> Void,
        onLive: @escaping (String) -> Void,
        onRewrite: @escaping (String) -> Void
    ) async {
        note = nil
        livePhrase = ""
        languageName = ""
        dictatedText = ""
        heardOrder = []
        self.onSettled = onSettled
        self.onLive = onLive
        self.onRewrite = onRewrite
        committedThrough = 0
        lanes.removeAll()
        engines.removeAll()
        resultTasks.forEach { $0.cancel() }
        resultTasks.removeAll()
        session += 1
        let session = session
        preferredCode = TalkLanguageCatalog.preferredCode(
            deviceLanguageCode: Locale.current.language.languageCode?.identifier,
            remembered: UserDefaults.standard.string(forKey: TalkLanguageCatalog.memoryKey)
        )

        guard await requestPermissions() else { return }
        guard session == self.session else { return }

        do {
            guard SpeechTranscriber.isAvailable else {
                note = "Speech isn’t available on this iPhone."
                return
            }
            var locale = await SpeechTranscriber.supportedLocale(equivalentTo: Locale(identifier: "en-IN"))
            if locale == nil {
                locale = await SpeechTranscriber.supportedLocale(equivalentTo: Locale(identifier: "en-US"))
            }
            if locale == nil {
                locale = await SpeechTranscriber.supportedLocale(equivalentTo: Locale(identifier: "en-GB"))
            }
            guard let locale else {
                note = "Speech isn’t available for this language on this iPhone."
                return
            }
            let voice = TalkVoice(
                language: TalkLanguageCatalog.language(matching: locale),
                locale: locale,
                usesDictationModel: false
            )
            voices = [voice]
            let transcriber = SpeechTranscriber(
                locale: locale,
                transcriptionOptions: [],
                reportingOptions: [.volatileResults, .fastResults],
                attributeOptions: []
            )
            do {
                note = "Downloading the on-device speech model…"
                try await TalkModelInstaller.install(transcriber)
            } catch {
                note = "The on-device speech model isn’t available for this language."
                return
            }
            guard session == self.session else { return }
            if await TalkVoices.reserve(locale) == false {
                await TalkVoices.releaseReservations()
                guard await TalkVoices.reserve(locale) else {
                    note = "This iPhone can’t prepare on-device transcription."
                    return
                }
            }
            note = nil
            try await listen(
                with: TalkEnginePair(voice: voice, engine: .speech(transcriber)),
                session: session
            )
        } catch {
            await stop()
            note = (error as? DictationError)?.message ?? "The microphone couldn’t start. Try Talk again."
        }
    }

    /// Listens with one language model. Several at once can stop the microphone from opening.
    private func listen(with pair: TalkEnginePair, session: Int) async throws {
        let analyzer = SpeechAnalyzer(modules: [pair.engine.module])
        guard let format = await SpeechAnalyzer.bestAvailableAudioFormat(compatibleWith: [pair.engine.module]) else {
            throw DictationError.modelUnavailable
        }
        do {
            try await analyzer.prepareToAnalyze(in: format)
        } catch {
            await analyzer.cancelAndFinishNow()
            throw error
        }
        guard session == self.session else {
            await analyzer.cancelAndFinishNow()
            return
        }

        let (stream, continuation) = AsyncStream<AnalyzerInput>.makeStream()
        let feed = MicrophoneFeed(outputFormat: format, continuation: continuation)
        do {
            try configureAudioSession()
            try feed.start()
        } catch {
            feed.stop()
            await analyzer.cancelAndFinishNow()
            throw error
        }

        engines = [pair.engine]
        lanes[pair.voice.language.code] = HeardLane(language: pair.voice.language)
        watch(pair.engine, code: pair.voice.language.code)
        self.analyzer = analyzer
        microphone = feed
        inputContinuation = continuation
        isListening = true
        note = nil

        analysisTask = Task {
            try? await analyzer.start(inputSequence: stream)
        }
    }

    private func watch(_ engine: TalkEngine, code: String) {
        switch engine {
        case .speech(let transcriber):
            resultTasks.append(Task { [weak self] in
                do {
                    for try await result in transcriber.results {
                        let end = result.range.end.seconds
                        await MainActor.run {
                            self?.take(
                                code: code,
                                text: String(result.text.characters),
                                isFinal: result.isFinal,
                                confidence: Self.confidence(in: result.text),
                                end: end.isFinite ? end : 0
                            )
                        }
                    }
                } catch {
                    await MainActor.run { self?.noteListeningStopped() }
                }
            })
        case .dictation(let transcriber):
            resultTasks.append(Task { [weak self] in
                do {
                    for try await result in transcriber.results {
                        let end = result.range.end.seconds
                        await MainActor.run {
                            self?.take(
                                code: code,
                                text: String(result.text.characters),
                                isFinal: result.isFinal,
                                confidence: Self.confidence(in: result.text),
                                end: end.isFinite ? end : 0
                            )
                        }
                    }
                } catch {
                    await MainActor.run { self?.noteListeningStopped() }
                }
            })
        }
    }

    private func take(code: String, text: String, isFinal: Bool, confidence: Double?, end: Double) {
        guard let lane = lanes[code] else { return }
        if end > 0, end <= committedThrough + 0.08 { return }
        if let confidence {
            lane.confidence = confidence
        }
        if isFinal {
            let piece = text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !piece.isEmpty else { return }
            let current = lane.pending.trimmingCharacters(in: .whitespacesAndNewlines)
            if !current.isEmpty, piece.hasPrefix(current) {
                lane.pending = piece
            } else if current.hasPrefix(piece), !piece.isEmpty, piece.count < current.count {
                return
            } else {
                lane.pending = DictationTranscript.join(base: lane.pending, spoken: piece)
            }
            lane.pendingEnd = max(lane.pendingEnd, end)
            lane.volatile = ""
            scheduleCommit()
            refreshLive()
        } else {
            lane.volatile = text
            refreshLive()
        }
    }

    private func scheduleCommit() {
        commitTask?.cancel()
        commitTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(220))
            guard !Task.isCancelled else { return }
            await MainActor.run { self?.commitPending() }
        }
    }

    private func commitRemainder() {
        for lane in lanes.values {
            let extra = lane.volatile.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !extra.isEmpty else { continue }
            lane.pending = DictationTranscript.join(base: lane.pending, spoken: extra)
            lane.volatile = ""
        }
        commitPending()
    }

    private func commitPending() {
        let ready = lanes.values.filter {
            !$0.pending.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        guard !ready.isEmpty else { return }
        let earliest = ready.map(\.pendingEnd).filter { $0 > 0 }.min() ?? 0
        let group = ready.filter { lane in
            earliest == 0 || lane.pendingEnd == 0 || lane.pendingEnd <= earliest + 1.2
        }
        guard let best = group.max(by: { lhs, rhs in
            let left = TalkLanguageCatalog.recognitionScore(text: lhs.pending, language: lhs.language, confidence: lhs.confidence)
            let right = TalkLanguageCatalog.recognitionScore(text: rhs.pending, language: rhs.language, confidence: rhs.confidence)
            if abs(left - right) < 0.12 {
                return preference(lhs) < preference(rhs)
            }
            return left < right
        }) else { return }

        let piece = best.pending.trimmingCharacters(in: .whitespacesAndNewlines)
        let end = group.map(\.pendingEnd).max() ?? 0
        if end > committedThrough {
            committedThrough = end
        }
        for lane in lanes.values {
            lane.volatile = ""
            if group.contains(where: { $0 === lane }) {
                lane.pending = ""
                lane.pendingEnd = 0
            }
        }
        dictatedText = DictationTranscript.join(base: dictatedText, spoken: piece)
        let guesses = TalkLanguageCatalog.romanizedGuesses(in: dictatedText)
        if guesses.isEmpty {
            languageName = best.language.name
            preferredCode = best.language.code
            TalkLanguageCatalog.remember(best.language.code)
            if heardOrder.isEmpty {
                note = nil
            }
        } else {
            absorbGuesses(guesses)
        }
        livePhrase = ""
        onLive?("")
        if !piece.isEmpty {
            onSettled?(piece)
        }
        refreshLive()
    }

    private func absorbGuesses(_ guesses: [RomanizedGuess]) {
        var next = guesses.map(\.code)
        for code in heardOrder where !next.contains(code) {
            next.append(code)
        }
        heardOrder = next
        guard let first = heardNames.first else { return }
        languageName = first
        if heardNames.count == 1 {
            note = "That sounds like \(first). I’ll rewrite it when you pause."
        } else {
            note = "That sounds like \(heardNames.joined(separator: " and ")). I’ll rewrite each when you pause."
        }
    }

    private var heardNames: [String] {
        heardOrder.compactMap { TalkLanguageCatalog.language(code: $0)?.name }
    }

    private func rewrite(snapshot: URL, original: String) async {
        defer { try? FileManager.default.removeItem(at: snapshot) }
        if let needed = heardOrder.first {
            let resolved = await TalkVoices.resolve(preferredCode: needed)
            for voice in resolved where !voices.contains(where: { $0.language.code == voice.language.code }) {
                voices.append(voice)
            }
        }
        var passes: [(code: String, fragments: [TalkFragment])] = []
        for code in heardOrder {
            guard let voice = voices.first(where: { $0.language.code == code }) else { continue }
            do {
                note = "Rewriting that in \(voice.language.name)."
                try await TalkModelInstaller.install(voice)
                if await TalkVoices.reserve(voice.locale) == false {
                    await TalkVoices.releaseReservations()
                    guard await TalkVoices.reserve(voice.locale) else { continue }
                }
                let fragments = try await transcribeFile(at: snapshot, voice: voice)
                passes.append((code, fragments))
            } catch {
                continue
            }
        }
        let rewritten = TalkLanguageCatalog.rewrittenText(passes: passes)
        guard TalkLanguageCatalog.isNativeRewrite(rewritten, replacing: original) else {
            note = "That language isn’t ready on this iPhone yet. The sounded-out words are still here."
            return
        }
        dictatedText = rewritten
        onRewrite?(rewritten)
        if let code = heardOrder.first {
            preferredCode = code
            TalkLanguageCatalog.remember(code)
            languageName = TalkLanguageCatalog.language(code: code)?.name ?? languageName
        }
        heardOrder = []
        note = nil
    }

    private func transcribeFile(at url: URL, voice: TalkVoice) async throws -> [TalkFragment] {
        let pair = TalkVoices.engines(for: [voice], confidence: true)[0]
        let analyzer = SpeechAnalyzer(modules: [pair.engine.module])
        let file = try AVAudioFile(forReading: url)
        guard let format = await SpeechAnalyzer.bestAvailableAudioFormat(
            compatibleWith: [pair.engine.module],
            considering: file.processingFormat
        ) else {
            throw DictationError.modelUnavailable
        }
        try await analyzer.prepareToAnalyze(in: format)
        let box = FragmentBox()
        let watch: Task<Void, Never>
        switch pair.engine {
        case .speech(let transcriber):
            watch = Task { @MainActor in
                do {
                    for try await result in transcriber.results {
                        box.add(result.text, range: result.range)
                    }
                } catch {}
            }
        case .dictation(let transcriber):
            watch = Task { @MainActor in
                do {
                    for try await result in transcriber.results {
                        box.add(result.text, range: result.range)
                    }
                } catch {}
            }
        }
        try await analyzer.start(inputAudioFile: file, finishAfterFile: true)
        try? await Task.sleep(for: .milliseconds(500))
        watch.cancel()
        await analyzer.cancelAndFinishNow()
        return box.items
    }

    private func refreshLive() {
        let visible = lanes.values.compactMap { lane -> (HeardLane, String, Double)? in
            let text = DictationTranscript.join(
                base: lane.pending,
                spoken: lane.volatile.trimmingCharacters(in: .whitespacesAndNewlines)
            )
            let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { return nil }
            let score = TalkLanguageCatalog.recognitionScore(text: trimmed, language: lane.language, confidence: lane.confidence)
            return (lane, trimmed, score)
        }
        guard !visible.isEmpty else {
            if lanes.values.allSatisfy({ $0.pending.isEmpty && $0.volatile.isEmpty }) {
                livePhrase = ""
                onLive?("")
            }
            return
        }
        let best = visible.max { lhs, rhs in
            if abs(lhs.2 - rhs.2) < 0.12 {
                return preference(lhs.0) < preference(rhs.0)
            }
            return lhs.2 < rhs.2
        }
        guard let best else { return }
        livePhrase = best.1
        onLive?(best.1)
        revealLanguage(best.0, text: best.1)
    }

    private func revealLanguage(_ lane: HeardLane, text: String) {
        let script = TalkLanguageCatalog.dominantScript(in: text, latinMinimum: 4)
        switch script {
        case .han, .devanagari, .bengali, .tamil, .cyrillic:
            if script == lane.language.script {
                languageName = lane.language.name
            }
        case .arabic, .latin:
            if let detected = TalkLanguageCatalog.detect(in: text), detected.code == lane.language.code {
                languageName = lane.language.name
            }
        case nil:
            break
        }
    }

    private func preference(_ lane: HeardLane) -> Int {
        if lane.language.code == preferredCode { return 2 }
        if lane.language.code == "en" { return 1 }
        return 0
    }

    private func noteListeningStopped() {
        guard isListening, lanes.isEmpty else { return }
        note = "Listening stopped."
    }

    private static func confidence(in text: AttributedString) -> Double? {
        let values = text.runs.compactMap(\.transcriptionConfidence)
        guard !values.isEmpty else { return nil }
        return values.reduce(0, +) / Double(values.count)
    }

    private func requestPermissions() async -> Bool {
        let microphone = await AVAudioApplication.requestRecordPermission()
        guard microphone else {
            note = "Allow the microphone to speak an entry."
            return false
        }

        let speech = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status)
            }
        }
        guard speech == .authorized else {
            note = "Allow speech recognition to transcribe on this iPhone."
            return false
        }
        return true
    }

    private func configureAudioSession() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
        try session.setActive(true)
    }
}

@available(iOS 26, *)
private struct TalkVoice: Sendable {
    let language: TalkLanguage
    let locale: Locale
    let usesDictationModel: Bool
}

@available(iOS 26, *)
private enum TalkEngine {
    case speech(SpeechTranscriber)
    case dictation(DictationTranscriber)

    var module: any SpeechModule {
        switch self {
        case .speech(let transcriber):
            transcriber
        case .dictation(let transcriber):
            transcriber
        }
    }
}

@available(iOS 26, *)
private struct TalkEnginePair {
    let voice: TalkVoice
    let engine: TalkEngine
}

@available(iOS 26, *)
private final class HeardLane {
    let language: TalkLanguage
    var volatile = ""
    var pending = ""
    var pendingEnd = 0.0
    var confidence: Double?

    init(language: TalkLanguage) {
        self.language = language
    }
}

@available(iOS 26, *)
private enum TalkVoices {
    static func resolve(preferredCode: String) async -> [TalkVoice] {
        let speechInstalled = SpeechTranscriber.isAvailable ? await SpeechTranscriber.installedLocales : []
        let dictationInstalled = await DictationTranscriber.installedLocales
        var voices: [TalkVoice] = []
        for language in TalkLanguageCatalog.activationOrder(preferredCode: preferredCode) {
            let speech = SpeechTranscriber.isAvailable ? await speechLocale(for: language) : nil
            let dictation = await dictationLocale(for: language)
            let speechReady = speech.map { locale in speechInstalled.contains { localesMatch($0, locale) } } ?? false
            let dictationReady = dictation.map { locale in dictationInstalled.contains { localesMatch($0, locale) } } ?? false
            if let speech, speechReady || dictation == nil || !dictationReady {
                voices.append(TalkVoice(language: language, locale: speech, usesDictationModel: false))
            } else if let dictation {
                voices.append(TalkVoice(language: language, locale: dictation, usesDictationModel: true))
            }
        }
        return voices
    }

    static func readiness(of voices: [TalkVoice]) async -> [String: Bool] {
        var ready: [String: Bool] = [:]
        await withTaskGroup(of: (String, Bool).self) { group in
            for voice in voices {
                group.addTask {
                    let installed = await TalkModelInstaller.isInstalled(voice)
                    return (voice.language.code, installed)
                }
            }
            for await (code, installed) in group {
                ready[code] = installed
            }
        }
        return ready
    }

    static func engines(for voices: [TalkVoice], confidence: Bool) -> [TalkEnginePair] {
        voices.map { voice in
            TalkEnginePair(voice: voice, engine: makeEngine(voice, confidence: confidence))
        }
    }

    static func compatible(_ pairs: [TalkEnginePair]) async -> [TalkEnginePair] {
        var set = pairs
        while !set.isEmpty {
            if await SpeechAnalyzer.bestAvailableAudioFormat(compatibleWith: set.map(\.engine.module)) != nil {
                return set
            }
            set.removeLast()
        }
        return []
    }

    static func reserve(_ locale: Locale) async -> Bool {
        let held = await AssetInventory.reservedLocales
        if held.contains(where: { localesMatch($0, locale) }) {
            return true
        }
        return (try? await AssetInventory.reserve(locale: locale)) ?? false
    }

    static func release(_ locale: Locale) async {
        let held = await AssetInventory.reservedLocales
        for reserved in held where localesMatch(reserved, locale) {
            _ = await AssetInventory.release(reservedLocale: reserved)
        }
    }

    static func releaseReservations() async {
        let held = await AssetInventory.reservedLocales
        for locale in held {
            _ = await AssetInventory.release(reservedLocale: locale)
        }
    }

    private static func makeEngine(_ voice: TalkVoice, confidence: Bool) -> TalkEngine {
        if voice.usesDictationModel {
            let attributes: Set<DictationTranscriber.ResultAttributeOption> = confidence ? [.transcriptionConfidence] : []
            return .dictation(DictationTranscriber(
                locale: voice.locale,
                contentHints: [],
                transcriptionOptions: [.punctuation],
                reportingOptions: [.volatileResults, .frequentFinalization],
                attributeOptions: attributes
            ))
        }
        let attributes: Set<SpeechTranscriber.ResultAttributeOption> = confidence ? [.transcriptionConfidence] : []
        return .speech(SpeechTranscriber(
            locale: voice.locale,
            transcriptionOptions: [],
            reportingOptions: [.volatileResults, .fastResults],
            attributeOptions: attributes
        ))
    }

    private static func speechLocale(for language: TalkLanguage) async -> Locale? {
        for identifier in language.localeIdentifiers {
            if let locale = await SpeechTranscriber.supportedLocale(equivalentTo: Locale(identifier: identifier)) {
                return locale
            }
        }
        return nil
    }

    private static func dictationLocale(for language: TalkLanguage) async -> Locale? {
        for identifier in language.localeIdentifiers {
            if let locale = await DictationTranscriber.supportedLocale(equivalentTo: Locale(identifier: identifier)) {
                return locale
            }
        }
        return nil
    }

    private static func localesMatch(_ lhs: Locale, _ rhs: Locale) -> Bool {
        let left = lhs.identifier(.bcp47)
        let right = rhs.identifier(.bcp47)
        if left.caseInsensitiveCompare(right) == .orderedSame {
            return true
        }
        guard left.split(separator: "-").first?.lowercased() == right.split(separator: "-").first?.lowercased() else {
            return false
        }
        let leftScript = lhs.language.script?.identifier
        let rightScript = rhs.language.script?.identifier
        return leftScript == rightScript || leftScript == nil || rightScript == nil
    }
}

@available(iOS 26, *)
private enum TalkModelInstaller {
    private static let gate = InstallGate()

    static func isInstalled(_ voice: TalkVoice) async -> Bool {
        let status = await AssetInventory.status(forModules: [probe(voice)])
        return status == .installed
    }

    static func install(_ module: any SpeechModule) async throws {
        switch await AssetInventory.status(forModules: [module]) {
        case .installed:
            return
        case .unsupported:
            throw DictationError.modelUnavailable
        case .supported, .downloading:
            guard let request = try await AssetInventory.assetInstallationRequest(supporting: [module]) else {
                return
            }
            try await request.downloadAndInstall()
        @unknown default:
            throw DictationError.modelUnavailable
        }
    }

    static func install(_ voice: TalkVoice) async throws {
        try await install(probe(voice))
    }

    static func installQueued(_ voices: [TalkVoice]) async {
        await gate.enqueue {
            for voice in voices {
                if Task.isCancelled { break }
                try? await install(voice)
            }
        }
    }

    private static func probe(_ voice: TalkVoice) -> any SpeechModule {
        if voice.usesDictationModel {
            return DictationTranscriber(
                locale: voice.locale,
                contentHints: [],
                transcriptionOptions: [],
                reportingOptions: [.volatileResults],
                attributeOptions: []
            )
        }
        return SpeechTranscriber(
            locale: voice.locale,
            transcriptionOptions: [],
            reportingOptions: [.volatileResults],
            attributeOptions: []
        )
    }
}

@available(iOS 26, *)
private actor InstallGate {
    private var tail: Task<Void, Never>?

    func enqueue(_ body: @escaping @Sendable () async -> Void) async {
        let previous = tail
        let next = Task {
            await previous?.value
            await body()
        }
        tail = next
        await next.value
    }
}

private enum DictationError: Error {
    case microphoneUnavailable
    case modelUnavailable

    var message: String {
        switch self {
        case .microphoneUnavailable:
            "The microphone isn’t available."
        case .modelUnavailable:
            "The on-device speech model isn’t available for this language."
        }
    }
}

@available(iOS 26, *)
private final class MicrophoneFeed: @unchecked Sendable {
    private let engine = AVAudioEngine()
    private let outputFormat: AVAudioFormat
    private let continuation: AsyncStream<AnalyzerInput>.Continuation
    private var converter: AVAudioConverter?
    private let recordingLock = NSLock()
    private var recorded: [AVAudioPCMBuffer] = []

    init(outputFormat: AVAudioFormat, continuation: AsyncStream<AnalyzerInput>.Continuation) {
        self.outputFormat = outputFormat
        self.continuation = continuation
    }

    func start() throws {
        let input = engine.inputNode
        let inputFormat = input.outputFormat(forBus: 0)
        guard inputFormat.sampleRate > 0, inputFormat.channelCount > 0 else {
            throw DictationError.microphoneUnavailable
        }
        guard let converter = AVAudioConverter(from: inputFormat, to: outputFormat) else {
            throw DictationError.microphoneUnavailable
        }
        self.converter = converter
        input.installTap(onBus: 0, bufferSize: 4096, format: inputFormat) { [weak self] buffer, _ in
            self?.yield(buffer)
        }
        engine.prepare()
        do {
            try engine.start()
        } catch {
            input.removeTap(onBus: 0)
            engine.stop()
            throw error
        }
    }

    func stop() {
        engine.inputNode.removeTap(onBus: 0)
        engine.stop()
    }

    private func yield(_ buffer: AVAudioPCMBuffer) {
        guard let converter else { return }
        let ratio = outputFormat.sampleRate / buffer.format.sampleRate
        let capacity = AVAudioFrameCount((Double(buffer.frameLength) * ratio).rounded(.up)) + 32
        guard let converted = AVAudioPCMBuffer(pcmFormat: outputFormat, frameCapacity: max(capacity, 32)) else { return }
        var error: NSError?
        var consumed = false
        converter.convert(to: converted, error: &error) { _, status in
            if consumed {
                status.pointee = .noDataNow
                return nil
            }
            consumed = true
            status.pointee = .haveData
            return buffer
        }
        guard error == nil, converted.frameLength > 0 else { return }
        store(converted)
        continuation.yield(AnalyzerInput(buffer: converted))
    }

    func snapshot() -> URL? {
        recordingLock.lock()
        let buffers = recorded
        recordingLock.unlock()
        guard !buffers.isEmpty, let format = buffers.first?.format else { return nil }
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("talk-\(UUID().uuidString)")
            .appendingPathExtension("caf")
        do {
            let file = try AVAudioFile(forWriting: url, settings: format.settings)
            for buffer in buffers {
                try file.write(from: buffer)
            }
            return url
        } catch {
            return nil
        }
    }

    private func store(_ buffer: AVAudioPCMBuffer) {
        guard let copy = AVAudioPCMBuffer(pcmFormat: buffer.format, frameCapacity: buffer.frameLength) else { return }
        copy.frameLength = buffer.frameLength
        let frames = Int(buffer.frameLength)
        let channels = Int(buffer.format.channelCount)
        if let source = buffer.floatChannelData, let destination = copy.floatChannelData {
            for channel in 0..<channels {
                destination[channel].update(from: source[channel], count: frames)
            }
        } else if let source = buffer.int16ChannelData, let destination = copy.int16ChannelData {
            for channel in 0..<channels {
                destination[channel].update(from: source[channel], count: frames)
            }
        } else {
            return
        }
        recordingLock.lock()
        recorded.append(copy)
        recordingLock.unlock()
    }
}

@available(iOS 26, *)
private final class FragmentBox: @unchecked Sendable {
    private let lock = NSLock()
    private var stored: [TalkFragment] = []

    func add(_ text: AttributedString, range: CMTimeRange) {
        let start = range.start.seconds
        let end = range.end.seconds
        let fragment = TalkFragment(
            text: String(text.characters),
            start: start.isFinite ? start : 0,
            end: end.isFinite ? end : 0
        )
        lock.lock()
        stored.append(fragment)
        lock.unlock()
    }

    var items: [TalkFragment] {
        lock.lock()
        defer { lock.unlock() }
        return stored
    }
}
