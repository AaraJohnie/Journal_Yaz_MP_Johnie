import SwiftUI
import SwiftData

struct SettingsView: View {
    @AppStorage("displayName") private var displayName = "Aaradhana"
    @AppStorage("appearance") private var appearance = JournalAppearance.light.rawValue
    @AppStorage(AccountStore.signedInKey) private var isSignedIn = false
    @AppStorage(AccountStore.providerKey) private var authProvider = ""
    @AppStorage("reminderEnabled") private var reminderEnabled = false
    @AppStorage("reminderHour") private var reminderHour = 21
    @AppStorage("reminderMinute") private var reminderMinute = 0

    var body: some View {
        ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    section(title: "Appearance") {
                        HStack(spacing: 12) {
                            appearanceChoice(.light)
                            appearanceChoice(.dark)
                        }
                        Text("Light keeps the page pale. Dark is the evening version.")
                            .font(.caption)
                            .foregroundStyle(JournalTheme.inkSoft)
                    }
                    section(title: "You") {
                        TextField("Name", text: $displayName)
                            .textFieldStyle(.plain)
                            .font(.body)
                            .foregroundStyle(JournalTheme.ink)
                    }
                    section(title: "Reminder") {
                        Toggle("Daily reminder", isOn: $reminderEnabled)
                            .tint(JournalTheme.accent)
                            .onChange(of: reminderEnabled) { _, enabled in
                                Task { await updateReminder(enabled: enabled) }
                            }
                        if reminderEnabled {
                            DatePicker(
                                "Time",
                                selection: reminderDate,
                                displayedComponents: .hourAndMinute
                            )
                            .onChange(of: reminderHour) { _, _ in
                                Task { await updateReminder(enabled: true) }
                            }
                            .onChange(of: reminderMinute) { _, _ in
                                Task { await updateReminder(enabled: true) }
                            }
                        }
                        Text("The reminder never includes what you wrote.")
                            .font(.caption)
                            .foregroundStyle(JournalTheme.inkSoft)
                    }
                    section(title: "Privacy") {
                        NavigationLink {
                            PrivateGateView()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "lock")
                                    .font(.body.weight(.medium))
                                Text("Private")
                                    .font(.body.weight(.medium))
                                Spacer(minLength: 12)
                                Image(systemName: "chevron.right")
                                    .font(.footnote.weight(.semibold))
                                    .foregroundStyle(JournalTheme.ink.opacity(0.45))
                            }
                            .foregroundStyle(JournalTheme.ink)
                            .padding(.horizontal, 22)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background { PrivacyPill() }
                        }
                        .buttonStyle(.plain)
                        Text("Private entries stay out of your journal, search, widgets, and notifications. Opening them asks for \(BiometricLock.availability().detail).")
                            .font(.caption)
                            .foregroundStyle(JournalTheme.inkSoft)
                    }
                    section(title: "Account") {
                        if !authProvider.isEmpty {
                            Text("Signed in with \(authProvider)")
                                .font(.body)
                                .foregroundStyle(JournalTheme.ink)
                        }
                        Button("Sign out") {
                            AccountStore.signOut()
                            isSignedIn = false
                        }
                        .buttonStyle(JournalButtonStyle())
                        Text("Signing out leaves your writing on this iPhone.")
                            .font(.caption)
                            .foregroundStyle(JournalTheme.inkSoft)
                    }
                    section(title: "Journal") {
                        ExportJournalButton()
                        Text("Stored only on this iPhone. Export includes your journal, not Private.")
                            .font(.caption)
                            .foregroundStyle(JournalTheme.inkSoft)
                    }
                }
                .padding(24)
            }
            .background(JournalBackground())
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.hidden, for: .navigationBar)
    }

    private var reminderDate: Binding<Date> {
        Binding(
            get: {
                var components = Calendar.current.dateComponents([.year, .month, .day], from: .now)
                components.hour = reminderHour
                components.minute = reminderMinute
                return Calendar.current.date(from: components) ?? .now
            },
            set: { date in
                let parts = Calendar.current.dateComponents([.hour, .minute], from: date)
                reminderHour = parts.hour ?? 21
                reminderMinute = parts.minute ?? 0
            }
        )
    }

    private func appearanceChoice(_ choice: JournalAppearance) -> some View {
        let selected = JournalAppearance.stored(appearance) == choice
        return Button {
            appearance = choice.rawValue
        } label: {
            Label(choice.title, systemImage: choice.symbol)
                .font(.body.weight(.medium))
                .foregroundStyle(JournalTheme.ink)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background { GlassSurface(isSelected: selected) }
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private func section(title: String, @ViewBuilder content: () -> some View) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.system(.subheadline, design: .serif))
                .tracking(1.1)
                .textCase(.uppercase)
                .foregroundStyle(JournalTheme.inkSoft)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func updateReminder(enabled: Bool) async {
        if enabled {
            await NotificationScheduler.schedule(at: reminderDate.wrappedValue)
        } else {
            NotificationScheduler.cancel()
        }
    }
}

private struct PrivacyPill: View {
    var body: some View {
        Capsule()
            .fill(
                LinearGradient(
                    colors: [
                        JournalTheme.blushPink.opacity(0.55),
                        JournalTheme.card,
                        JournalTheme.blushGold.opacity(0.28)
                    ],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .overlay {
                Capsule()
                    .strokeBorder(
                        LinearGradient(
                            colors: [
                                JournalTheme.blushPink.opacity(0.28),
                                JournalTheme.blushGold.opacity(0.85),
                                Color.white.opacity(0.7)
                            ],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        lineWidth: 1
                    )
            }
            .shadow(color: JournalTheme.blushPink.opacity(0.34), radius: 18, y: 10)
            .shadow(color: JournalTheme.blushGold.opacity(0.16), radius: 6, y: 2)
    }
}

private struct ExportJournalButton: View {
    @Query(
        filter: #Predicate<JournalEntry> { $0.isPrivate == false },
        sort: \JournalEntry.createdAt,
        order: .reverse
    )
    private var entries: [JournalEntry]

    var body: some View {
        ShareLink(item: JournalVisibility.exportText(from: entries.map(\.visible))) {
            Label("Export journal", systemImage: "square.and.arrow.up")
                .font(.body.weight(.medium))
                .foregroundStyle(JournalTheme.ink)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background { GlassSurface() }
        }
        .buttonStyle(.plain)
    }
}
