import SwiftUI
import SwiftData

struct RootView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("appearance") private var appearance = JournalAppearance.light.rawValue
    @AppStorage(AccountStore.signedInKey) private var isSignedIn = false
    @State private var session = PrivateSession()
    @State private var cover = false

    var body: some View {
        ZStack {
            if isSignedIn {
                TabView {
                    HomeView()
                        .tabItem { Label("Home", systemImage: "house") }
                    ArchiveView()
                        .tabItem { Label("Journal", systemImage: "book.closed") }
                    SearchView()
                        .tabItem { Label("Search", systemImage: "magnifyingglass") }
                    MeView()
                        .tabItem { Label("Me", systemImage: "person") }
                }
                .tint(JournalTheme.accent)
            } else {
                WelcomeView()
            }

            if cover {
                AppSwitcherCover()
            }
        }
        .preferredColorScheme(JournalAppearance.stored(appearance).scheme)
        .environment(session)
        .task { JournalLibrary.publish(context) }
        .onChange(of: scenePhase) { _, phase in
            cover = phase != .active
            if phase == .background {
                session.lock()
            }
        }
    }
}

struct AppSwitcherCover: View {
    var body: some View {
        JournalTheme.paper
            .ignoresSafeArea()
            .overlay {
                Text("Journal")
                    .font(.system(.title2, design: .serif))
                    .foregroundStyle(JournalTheme.inkSoft)
            }
            .accessibilityHidden(true)
    }
}
