import SwiftUI
import SwiftData

struct PrivateGateView: View {
    @Environment(PrivateSession.self) private var session
    @Environment(\.scenePhase) private var scenePhase
    @State private var didAutoPrompt = false
    @State private var isAuthenticating = false

    var body: some View {
        Group {
            if session.isUnlocked && scenePhase == .active {
                PrivateJournalView()
            } else {
                PrivateLockView {
                    Task { await authenticate() }
                }
            }
        }
        .background(JournalBackground())
        .navigationTitle("Private")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: promptIfNeeded)
        .onChange(of: scenePhase) { _, phase in
            if phase == .background {
                session.lock()
                didAutoPrompt = false
            } else if phase == .active {
                promptIfNeeded()
            }
        }
    }

    private func promptIfNeeded() {
        guard scenePhase == .active, !session.isUnlocked, !didAutoPrompt, !isAuthenticating else { return }
        didAutoPrompt = true
        Task { await authenticate() }
    }

    private func authenticate() async {
        guard !isAuthenticating else { return }
        isAuthenticating = true
        let success = await BiometricLock.unlock()
        isAuthenticating = false
        if success {
            session.isUnlocked = true
        }
    }
}

struct PrivateLockView: View {
    var onUnlock: () -> Void
    private var availability: BiometricLock.Availability { BiometricLock.availability() }

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "lock")
                .font(.system(size: 28, weight: .light))
                .foregroundStyle(JournalTheme.ink)
            Text("Private")
                .font(.system(.title, design: .serif))
                .foregroundStyle(JournalTheme.ink)
            Text(availability.isReady ? availability.detail : availability.detail)
                .font(.subheadline)
                .foregroundStyle(JournalTheme.inkSoft)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 36)
            if availability.isReady {
                Button("Unlock", action: onUnlock)
                    .buttonStyle(JournalButtonStyle())
                    .padding(.top, 8)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(JournalBackground())
    }
}

struct PrivateJournalView: View {
    @Environment(PrivateSession.self) private var session
    @Query(
        filter: #Predicate<JournalEntry> { $0.isPrivate == true },
        sort: \JournalEntry.createdAt,
        order: .reverse
    )
    private var entries: [JournalEntry]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Only on this iPhone, after \(BiometricLock.availability().method) or your passcode.")
                    .font(.subheadline)
                    .foregroundStyle(JournalTheme.inkSoft)
                if entries.isEmpty {
                    EmptyNote(
                        title: "Nothing private yet",
                        message: "Mark an entry Private and it will wait here, out of search, widgets, and reminders."
                    )
                    .padding(.top, 12)
                } else {
                    ForEach(entries) { entry in
                        NavigationLink {
                            JournalEntryView(entry: entry, allowsPrivateContent: true)
                        } label: {
                            EntryCard(
                                title: entry.title,
                                content: entry.content,
                                mood: entry.mood,
                                date: entry.createdAt,
                                showsTime: false
                            )
                        }
                        .buttonStyle(.plain)
                        .privacySensitive()
                    }
                }
            }
            .padding(24)
        }
        .background(JournalBackground())
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    session.lock()
                } label: {
                    Image(systemName: "lock")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("Lock")
                NavigationLink {
                    ComposeView(startsPrivate: true)
                } label: {
                    Image(systemName: "square.and.pencil")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("New private entry")
            }
        }
    }
}
