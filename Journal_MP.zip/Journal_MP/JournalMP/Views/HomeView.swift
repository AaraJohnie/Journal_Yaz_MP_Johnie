import SwiftUI
import SwiftData

struct HomeView: View {
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("displayName") private var displayName = "Aaradhana"
    @Query(
        filter: #Predicate<JournalEntry> { $0.isPrivate == false },
        sort: \JournalEntry.createdAt,
        order: .reverse
    )
    private var publicEntries: [JournalEntry]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    header
                    todaySection
                    recentSection
                    privateLink
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            }
            .background(JournalBackground())
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        ComposeView(startsPrivate: false)
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                    .buttonStyle(GlassIconButtonStyle())
                    .accessibilityLabel("New entry")
                }
            }
            .toolbarBackground(.hidden, for: .navigationBar)
        }
    }

    private var header: some View {
        TimelineView(.everyMinute) { context in
            let date = scenePhase == .active ? Date.now : context.date
            VStack(alignment: .leading, spacing: 6) {
                Text(Greeting.text(name: displayName, date: date))
                    .font(.system(.largeTitle, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                Text(date.formatted(.dateTime.weekday(.wide).month(.wide).day()))
                    .font(.subheadline)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
            .padding(.top, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var todayEntry: JournalEntry? {
        publicEntries.first { Calendar.current.isDateInToday($0.createdAt) }
    }

    @ViewBuilder
    private var todaySection: some View {
        if let todayEntry {
            NavigationLink {
                JournalEntryView(entry: todayEntry, allowsPrivateContent: false)
            } label: {
                EntryCard(
                    title: todayEntry.title,
                    content: todayEntry.content,
                    mood: todayEntry.mood,
                    date: todayEntry.createdAt
                )
            }
            .buttonStyle(.plain)
            NavigationLink {
                ComposeView(startsPrivate: false)
            } label: {
                Text("Write another")
            }
            .buttonStyle(JournalButtonStyle())
            if #available(iOS 26, *) {
                NavigationLink {
                    ComposeView(startsPrivate: false, startsTalking: true)
                } label: {
                    Label("Talk", systemImage: "waveform")
                }
                .buttonStyle(JournalButtonStyle())
            }
        } else {
            VStack(alignment: .leading, spacing: 18) {
                EmptyNote(
                    title: "How was your day?",
                    message: DailyPrompt.forDate(.now)
                )
                NavigationLink {
                    ComposeView(startsPrivate: false)
                } label: {
                    Text("Write today's entry")
                }
                .buttonStyle(JournalButtonStyle())
                if #available(iOS 26, *) {
                    NavigationLink {
                        ComposeView(startsPrivate: false, startsTalking: true)
                    } label: {
                        Label("Talk", systemImage: "waveform")
                    }
                    .buttonStyle(JournalButtonStyle())
                }
            }
        }
    }

    private var recentEntries: [JournalEntry] {
        let featuredID = todayEntry?.id
        return publicEntries.filter { $0.id != featuredID }
    }

    @ViewBuilder
    private var recentSection: some View {
        if !recentEntries.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text("Recent")
                    .font(.system(.subheadline, design: .serif))
                    .tracking(1.1)
                    .textCase(.uppercase)
                    .foregroundStyle(JournalTheme.inkSoft)
                    .padding(.bottom, 8)
                ForEach(recentEntries.prefix(8)) { entry in
                    NavigationLink {
                        JournalEntryView(entry: entry, allowsPrivateContent: false)
                    } label: {
                        EntryRow(title: entry.title, content: entry.content, date: entry.createdAt)
                    }
                    .buttonStyle(.plain)
                    Divider().overlay(JournalTheme.rule)
                }
            }
        }
    }

    private var privateLink: some View {
        NavigationLink {
            PrivateGateView()
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "lock")
                    .font(.body.weight(.light))
                VStack(alignment: .leading, spacing: 2) {
                    Text("Private")
                        .font(.system(.body, design: .serif))
                    Text(BiometricLock.availability().detail)
                        .font(.caption)
                        .foregroundStyle(JournalTheme.inkSoft)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(JournalTheme.inkSoft)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .foregroundStyle(JournalTheme.ink)
            .background { GlassSurface() }
        }
        .buttonStyle(.plain)
        .accessibilityHint("Requires \(BiometricLock.availability().method) or your device passcode")
    }
}
