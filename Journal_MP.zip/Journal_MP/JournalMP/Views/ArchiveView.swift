import SwiftUI
import SwiftData

struct ArchiveView: View {
    @State private var favoritesOnly = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 8) {
                    MemoryTimeline()
                    if favoritesOnly {
                        ArchiveList(favoritesOnly: true)
                    } else {
                        ArchiveList(favoritesOnly: false)
                    }
                }
            }
            .background(JournalBackground())
            .navigationTitle("Journal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        favoritesOnly.toggle()
                    } label: {
                        Image(systemName: favoritesOnly ? "heart.fill" : "heart")
                    }
                    .buttonStyle(GlassIconButtonStyle())
                    .accessibilityLabel(favoritesOnly ? "Show all entries" : "Show favourites")
                }
            }
            .toolbarBackground(.hidden, for: .navigationBar)
        }
    }
}

private struct ArchiveList: View {
    @Query private var entries: [JournalEntry]

    init(favoritesOnly: Bool) {
        if favoritesOnly {
            _entries = Query(
                filter: #Predicate<JournalEntry> { $0.isPrivate == false && $0.isFavorite },
                sort: \JournalEntry.createdAt,
                order: .reverse
            )
        } else {
            _entries = Query(
                filter: #Predicate<JournalEntry> { $0.isPrivate == false },
                sort: \JournalEntry.createdAt,
                order: .reverse
            )
        }
    }

    var body: some View {
        Group {
            if entries.isEmpty {
                EmptyNote(
                    title: "Nothing here yet",
                    message: "Entries you write will gather here. Private ones stay in their own folder."
                )
                .padding(24)
            } else {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(sections, id: \.title) { section in
                        Text(section.title)
                            .font(.system(.subheadline, design: .serif))
                            .tracking(1.1)
                            .textCase(.uppercase)
                            .foregroundStyle(JournalTheme.inkSoft)
                            .padding(.top, 22)
                            .padding(.bottom, 8)
                        ForEach(section.entries) { entry in
                            NavigationLink {
                                JournalEntryView(entry: entry, allowsPrivateContent: false)
                            } label: {
                                EntryRow(title: entry.title, content: entry.content, date: entry.createdAt)
                            }
                            .buttonStyle(.plain)
                            Divider().overlay(JournalTheme.rule)
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            }
        }
    }

    private var sections: [(title: String, entries: [JournalEntry])] {
        let grouped = Dictionary(grouping: entries) { entry in
            entry.createdAt.formatted(.dateTime.month(.wide).year())
        }
        return grouped.keys.sorted { lhs, rhs in
            let left = grouped[lhs]?.first?.createdAt ?? .distantPast
            let right = grouped[rhs]?.first?.createdAt ?? .distantPast
            return left > right
        }
        .map { ($0, grouped[$0] ?? []) }
    }
}

private struct MemoryTimeline: View {
    @Query(
        filter: #Predicate<JournalEntry> { $0.isPrivate == false },
        sort: \JournalEntry.createdAt,
        order: .reverse
    )
    private var entries: [JournalEntry]
    @State private var month = Date.now

    private var calendar: Calendar { MoodMemory.mondayCalendar(.current) }
    private var notes: [MemoryNote] {
        entries.map { MemoryNote(date: $0.createdAt, mood: $0.mood, isFavorite: $0.isFavorite) }
    }
    private var marks: [MoodMemory.DayMark] {
        MoodMemory.marks(in: month, from: notes, calendar: calendar)
    }
    private var monthCount: Int {
        MoodMemory.notes(in: month, from: notes, calendar: calendar).count
    }
    private var topMoods: [MoodMemory.MoodCount] {
        MoodMemory.topMoods(in: month, from: notes, calendar: calendar)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Your month")
                .font(.system(.subheadline, design: .serif))
                .tracking(1.1)
                .textCase(.uppercase)
                .foregroundStyle(JournalTheme.inkSoft)

            HStack {
                Button {
                    shiftMonth(by: -1)
                } label: {
                    Image(systemName: "chevron.left")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("Previous month")

                Spacer()
                Text(month.formatted(.dateTime.month(.wide)))
                    .font(.system(.title2, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                Spacer()

                Button {
                    shiftMonth(by: 1)
                } label: {
                    Image(systemName: "chevron.right")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("Next month")
            }

            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 7), spacing: 10) {
                ForEach(weekdayLabels, id: \.self) { label in
                    Text(label)
                        .font(.caption2)
                        .foregroundStyle(JournalTheme.inkSoft)
                        .frame(maxWidth: .infinity)
                }
                ForEach(0..<MoodMemory.leadingBlanks(in: month, calendar: calendar), id: \.self) { _ in
                    Color.clear.frame(height: 44)
                }
                ForEach(marks) { mark in
                    dayCell(mark)
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(month.formatted(.dateTime.month(.wide)))
                    .font(.system(.title3, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                Text(monthLine)
                    .font(.subheadline)
                    .foregroundStyle(JournalTheme.inkSoft)
                if !topMoods.isEmpty {
                    Text("Most used moods")
                        .font(.caption)
                        .foregroundStyle(JournalTheme.inkSoft)
                        .padding(.top, 8)
                    ForEach(topMoods) { mood in
                        Text("\(mood.mood.symbol)  \(mood.mood.rawValue)")
                            .font(.body)
                            .foregroundStyle(JournalTheme.ink)
                    }
                }
            }
            .padding(.top, 8)
        }
        .padding(.horizontal, 24)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }

    private var monthLine: String {
        switch monthCount {
        case 0: "A quiet month"
        case 1: "1 entry"
        default: "\(monthCount) entries"
        }
    }

    private var weekdayLabels: [String] {
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    }

    @ViewBuilder
    private func dayCell(_ mark: MoodMemory.DayMark) -> some View {
        let dayEntries = entries.filter { calendar.isDate($0.createdAt, inSameDayAs: mark.day) }
        if dayEntries.isEmpty {
            dayLabel(mark)
        } else if dayEntries.count == 1, let entry = dayEntries.first {
            NavigationLink {
                JournalEntryView(entry: entry, allowsPrivateContent: false)
            } label: {
                dayLabel(mark)
            }
            .buttonStyle(.plain)
        } else {
            NavigationLink {
                DayEntriesView(day: mark.day, entries: dayEntries)
            } label: {
                dayLabel(mark)
            }
            .buttonStyle(.plain)
        }
    }

    private func dayLabel(_ mark: MoodMemory.DayMark) -> some View {
        VStack(spacing: 2) {
            Text(mark.symbol ?? " ")
                .font(.body)
                .frame(height: 22)
            Text(mark.day.formatted(.dateTime.day()))
                .font(.caption2)
                .foregroundStyle(mark.symbol == nil ? JournalTheme.inkSoft : JournalTheme.ink)
        }
        .frame(maxWidth: .infinity, minHeight: 44)
        .accessibilityLabel(mark.symbol == nil ? mark.label : "\(mark.label), \(mark.symbol ?? "")")
    }

    private func shiftMonth(by value: Int) {
        if let next = calendar.date(byAdding: .month, value: value, to: month) {
            month = next
        }
    }
}

private struct DayEntriesView: View {
    var day: Date
    var entries: [JournalEntry]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Text(day.formatted(.dateTime.weekday(.wide).month(.wide).day()))
                    .font(.system(.title3, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                    .padding(.bottom, 12)
                ForEach(entries) { entry in
                    NavigationLink {
                        JournalEntryView(entry: entry, allowsPrivateContent: false)
                    } label: {
                        EntryRow(title: entry.title, content: entry.content, date: entry.createdAt)
                    }
                    .buttonStyle(.plain)
                    Divider().overlay(JournalTheme.rule)
                }
            }
            .padding(24)
        }
        .background(JournalBackground())
        .navigationTitle("That day")
        .navigationBarTitleDisplayMode(.inline)
    }
}
