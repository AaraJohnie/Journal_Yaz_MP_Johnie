import AuthenticationServices
import SwiftUI

struct WelcomeView: View {
    @AppStorage(AccountStore.signedInKey) private var isSignedIn = false
    @State private var page = 0
    @State private var note: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 28) {
            Spacer(minLength: 12)
            TabView(selection: $page) {
                welcomePage(
                    title: "Your journal",
                    message: "A quiet place for the days you want to keep.",
                    tag: 0
                )
                welcomePage(
                    title: "Write, or talk",
                    message: "The words stay on this iPhone. A private folder opens only for you.",
                    tag: 1
                )
                signInPage
                    .tag(2)
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .frame(maxHeight: 420)

            if page < 2 {
                Button("Continue") {
                    withAnimation { page = min(page + 1, 2) }
                }
                .buttonStyle(JournalButtonStyle())
            }
            if let note {
                Text(note)
                    .font(.caption)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
            Spacer(minLength: 8)
        }
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(JournalBackground())
    }

    private func welcomePage(title: String, message: String, tag: Int) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(.system(.largeTitle, design: .serif))
                .foregroundStyle(JournalTheme.ink)
            Text(message)
                .font(.title3)
                .foregroundStyle(JournalTheme.inkSoft)
                .fixedSize(horizontal: false, vertical: true)
            Spacer()
        }
        .tag(tag)
    }

    private var signInPage: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Begin")
                .font(.system(.largeTitle, design: .serif))
                .foregroundStyle(JournalTheme.ink)
            Text("Sign in to open your journal. What you write stays on this iPhone.")
                .font(.body)
                .foregroundStyle(JournalTheme.inkSoft)
            SignInWithAppleButton(.continue) { request in
                request.requestedScopes = [.fullName, .email]
            } onCompletion: { result in
                switch result {
                case .success(let authorization):
                    completeApple(authorization)
                case .failure(let error):
                    if let authError = error as? ASAuthorizationError, authError.code == .canceled {
                        note = nil
                    } else {
                        note = AccountError.failed.errorDescription
                    }
                }
            }
            .signInWithAppleButtonStyle(.black)
            .frame(height: 52)
            .clipShape(Capsule())

            Button {
                Task { await completeGoogle() }
            } label: {
                Text("Continue with Google")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(JournalButtonStyle())
            Spacer()
        }
    }

    private func completeApple(_ authorization: ASAuthorization) {
        guard let credential = authorization.credential as? ASAuthorizationAppleIDCredential else {
            note = AccountError.failed.errorDescription
            return
        }
        let name = [credential.fullName?.givenName, credential.fullName?.familyName]
            .compactMap { $0 }
            .joined(separator: " ")
        AccountStore.save(AccountProfile(userID: credential.user, name: name.isEmpty ? nil : name, provider: "Apple"))
        isSignedIn = true
    }

    private func completeGoogle() async {
        do {
            let profile = try await AccountSession.signInWithGoogle()
            AccountStore.save(profile)
            isSignedIn = true
        } catch AccountError.cancelled {
            note = nil
        } catch {
            note = error.localizedDescription
        }
    }
}
