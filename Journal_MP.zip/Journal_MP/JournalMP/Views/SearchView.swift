import SwiftUI
import SwiftData

struct SearchView: View {
    @State private var query = ""

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 0) {
                TextField("Search your thoughts", text: $query)
                    .textFieldStyle(.plain)
                    .font(.body)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                    .background { GlassSurface() }
                    .padding(.horizontal, 24)
                    .padding(.top, 12)
                    .accessibilityLabel("Search your thoughts")

                if query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    EmptyNote(
                        title: "Search",
                        message: "Look through your journal. Private entries are not included."
                    )
                    .padding(24)
                    Spacer()
                } else {
                    SearchResults(query: query)
                        .id(query)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(JournalBackground())
            .navigationTitle("Search")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.hidden, for: .navigationBar)
        }
    }
}

private struct SearchResults: View {
    @Query private var results: [JournalEntry]
    private let query: String

    init(query: String) {
        self.query = query
        let needle = query
        _results = Query(
            filter: #Predicate<JournalEntry> { entry in
                entry.isPrivate == false && (
                    entry.title.localizedStandardContains(needle)
                        || entry.content.localizedStandardContains(needle)
                )
            },
            sort: \JournalEntry.createdAt,
            order: .reverse
        )
    }

    var body: some View {
        ScrollView {
            if results.isEmpty {
                EmptyNote(title: "No entries", message: "Nothing in your journal matches.")
                    .padding(24)
            } else {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(results) { entry in
                        NavigationLink {
                            JournalEntryView(entry: entry, allowsPrivateContent: false, searchQuery: query)
                        } label: {
                            EntryRow(title: entry.title, content: entry.content, date: entry.createdAt)
                        }
                        .buttonStyle(.plain)
                        Divider().overlay(JournalTheme.rule)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 12)
            }
        }
    }
}
