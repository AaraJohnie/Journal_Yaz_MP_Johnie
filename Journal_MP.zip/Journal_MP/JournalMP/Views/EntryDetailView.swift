import SwiftUI
import SwiftData

struct JournalEntryView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Bindable var entry: JournalEntry
    var allowsPrivateContent: Bool
    var searchQuery: String? = nil

    @State private var confirmPrivate = false
    @State private var confirmPublic = false
    @State private var confirmDelete = false
    @State private var showEditor = false

    var body: some View {
        Group {
            if entry.isPrivate && !allowsPrivateContent {
                EmptyNote(
                    title: "Private",
                    message: "This entry is locked. Open Private to read it."
                )
                .padding(24)
            } else {
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 16) {
                            Text(entry.createdAt.formatted(.dateTime.weekday(.wide).month(.wide).day().hour().minute()))
                                .font(.subheadline)
                                .foregroundStyle(JournalTheme.inkSoft)
                            if !entry.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                HighlightedText(text: entry.title, query: searchQuery, font: .system(.title, design: .serif))
                                    .id(focus == .title ? "search-match" : "entry-title")
                            }
                            if let match = Mood.resolved(entry.mood) {
                                Text("\(match.symbol)  \(match.rawValue)")
                                    .font(.subheadline)
                                    .foregroundStyle(JournalTheme.inkSoft)
                            }
                            VStack(alignment: .leading, spacing: 10) {
                                ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                                    HighlightedText(text: paragraph, query: searchQuery, font: .body)
                                        .id(focus == .paragraph(index) ? "search-match" : "paragraph-\(index)")
                                }
                            }
                            .privacySensitive(entry.isPrivate)
                        }
                        .padding(24)
                    }
                    .onAppear {
                        guard focus != nil else { return }
                        DispatchQueue.main.async {
                            withAnimation(.easeInOut(duration: 0.35)) {
                                proxy.scrollTo("search-match", anchor: .center)
                            }
                        }
                    }
                }
            }
        }
        .background(JournalBackground())
        .navigationTitle(entry.isPrivate ? "Private" : entry.createdAt.formatted(date: .abbreviated, time: .omitted))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if !entry.isPrivate || allowsPrivateContent {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button {
                        entry.isFavorite.toggle()
                        try? context.save()
                    } label: {
                        Image(systemName: entry.isFavorite ? "heart.fill" : "heart")
                    }
                    .buttonStyle(GlassIconButtonStyle())
                    .accessibilityLabel(entry.isFavorite ? "Remove favourite" : "Favourite")

                    Menu {
                        Button {
                            showEditor = true
                        } label: {
                            Label("Edit", systemImage: "pencil")
                        }
                        if entry.isPrivate {
                            Button("Move to Journal") { confirmPublic = true }
                        } else {
                            Button("Move to Private") { confirmPrivate = true }
                        }
                        if !entry.isPrivate {
                            ShareLink(item: shareText) {
                                Label("Share", systemImage: "square.and.arrow.up")
                            }
                        }
                        Button("Delete", role: .destructive) { confirmDelete = true }
                    } label: {
                        Image(systemName: "ellipsis")
                    }
                    .buttonStyle(GlassIconButtonStyle())
                }
            }
        }
        .confirmationDialog("Move to Private?", isPresented: $confirmPrivate, titleVisibility: .visible) {
            Button("Move to Private") {
                try? JournalLibrary.setPrivate(entry, true, in: context)
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("It will leave your journal, search, widgets, and reminders. Open it again with Face ID, Touch ID, or your passcode.")
        }
        .confirmationDialog("Move to Journal?", isPresented: $confirmPublic, titleVisibility: .visible) {
            Button("Move to Journal") {
                try? JournalLibrary.setPrivate(entry, false, in: context)
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("It will show in your journal, search, and widgets again.")
        }
        .navigationDestination(isPresented: $showEditor) {
            ComposeView(startsPrivate: entry.isPrivate, existing: entry)
        }
        .confirmationDialog("Delete this entry?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                try? JournalLibrary.delete(entry, in: context)
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        }
    }

    private var focus: SearchHighlight.Focus? {
        guard let searchQuery else { return nil }
        return SearchHighlight.focus(title: entry.title, content: entry.content, query: searchQuery)
    }

    private var paragraphs: [String] {
        let parts = entry.content.components(separatedBy: "\n")
        return parts.isEmpty ? [entry.content] : parts
    }

    private var shareText: String {
        let heading = entry.title.trimmingCharacters(in: .whitespacesAndNewlines)
        if heading.isEmpty { return entry.content }
        return "\(heading)\n\n\(entry.content)"
    }
}

private struct HighlightedText: View {
    let text: String
    let query: String?
    let font: Font

    var body: some View {
        Text(highlighted)
            .font(font)
            .foregroundStyle(JournalTheme.ink)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var highlighted: AttributedString {
        var attributed = AttributedString(text)
        guard let query else { return attributed }
        for range in SearchHighlight.ranges(in: text, query: query) {
            guard let start = AttributedString.Index(range.lowerBound, within: attributed),
                  let end = AttributedString.Index(range.upperBound, within: attributed) else { continue }
            attributed[start..<end].backgroundColor = JournalTheme.blushPink.opacity(0.55)
            attributed[start..<end].foregroundColor = JournalTheme.ink
        }
        return attributed
    }
}
