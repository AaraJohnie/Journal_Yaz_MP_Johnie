import SwiftUI
import SwiftData

struct ComposeView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase

    var startsPrivate: Bool
    var startsTalking: Bool
    var existing: JournalEntry?

    @State private var title = ""
    @State private var content = ""
    @State private var mood: String?
    @State private var isPrivate = false
    @State private var workingEntry: JournalEntry?
    @State private var createdThisSession = false
    @State private var reviewBeforeSave = false

    init(startsPrivate: Bool, startsTalking: Bool = false, existing: JournalEntry? = nil) {
        self.startsPrivate = startsPrivate
        self.startsTalking = startsTalking
        self.existing = existing
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                TextField("Title", text: $title)
                    .font(.system(.title2, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                TalkPage(content: $content, reviewBeforeSave: $reviewBeforeSave, startsTalking: startsTalking)
                MoodPicker(mood: $mood)
                privateToggle
            }
            .padding(24)
        }
        .background(JournalBackground())
        .navigationTitle(isPrivate ? "Private" : (reviewBeforeSave ? "Talk" : "Entry"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button {
                    persist()
                    dismiss()
                } label: {
                    Text("Done")
                        .font(.body.weight(.medium))
                        .foregroundStyle(JournalTheme.ink)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background { GlassSurface() }
                }
                .buttonStyle(.plain)
            }
        }
        .onAppear(perform: load)
        .onChange(of: title) { _, _ in scheduleSave() }
        .onChange(of: content) { _, _ in scheduleSave() }
        .onChange(of: mood) { _, _ in scheduleSave() }
        .onChange(of: isPrivate) { _, _ in scheduleSave() }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { persist() }
        }
        .onDisappear(perform: persist)
        .privacySensitive(isPrivate)
    }

    private var privateToggle: some View {
        Toggle(isOn: $isPrivate) {
            VStack(alignment: .leading, spacing: 2) {
                Label("Private", systemImage: "lock")
                    .font(.body)
                    .foregroundStyle(JournalTheme.ink)
                Text(isPrivate
                     ? "Kept in Private. Hidden from search, widgets, and reminders."
                     : "Visible in your journal.")
                    .font(.caption)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
        }
        .tint(JournalTheme.accent)
        .padding(.top, 8)
    }

    private func load() {
        guard workingEntry == nil else { return }
        if let existing {
            workingEntry = existing
            title = existing.title
            content = existing.content
            mood = existing.mood
            isPrivate = existing.isPrivate
        } else {
            isPrivate = startsPrivate
        }
    }

    private func scheduleSave() {
        persist()
    }

    private func persist() {
        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedContent = content.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedTitle.isEmpty && trimmedContent.isEmpty {
            if createdThisSession, let workingEntry {
                context.delete(workingEntry)
                try? context.save()
                JournalLibrary.publish(context)
                self.workingEntry = nil
                createdThisSession = false
            }
            return
        }

        let entry: JournalEntry
        if let workingEntry {
            entry = workingEntry
        } else {
            entry = JournalEntry(isPrivate: isPrivate)
            createdThisSession = true
            workingEntry = entry
        }
        entry.title = title
        entry.content = content
        entry.mood = mood
        entry.isPrivate = isPrivate
        try? JournalLibrary.save(entry, in: context)
    }
}

private struct TalkPage: View {
    @Binding var content: String
    @Binding var reviewBeforeSave: Bool
    var startsTalking: Bool

    var body: some View {
        if #available(iOS 26, *) {
            LiveTalkPage(content: $content, reviewBeforeSave: $reviewBeforeSave, startsTalking: startsTalking)
        } else {
            WritingSurface(content: $content, livePhrase: "", isListening: false)
        }
    }
}

@available(iOS 26, *)
private struct LiveTalkPage: View {
    @Binding var content: String
    @Binding var reviewBeforeSave: Bool
    var startsTalking: Bool
    @Environment(\.scenePhase) private var scenePhase
    @State private var dictation = JournalDictation()
    @State private var spokenBaseline = ""
    @State private var spoken = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            WritingSurface(content: $content, livePhrase: dictation.livePhrase, isListening: dictation.isListening)
            Button {
                reviewBeforeSave = true
                Task { await dictation.toggle(onSettled: appendSpoken, onLive: { _ in }, onRewrite: replaceSpoken) }
            } label: {
                Label(dictation.isListening ? "Pause" : "Talk", systemImage: dictation.isListening ? "waveform" : "mic")
            }
            .buttonStyle(JournalButtonStyle())
            .accessibilityHint("Words appear as you speak. Edit them before you keep the entry.")

            Text(caption)
                .font(.caption)
                .foregroundStyle(JournalTheme.inkSoft)
            Text("English")
                .font(.caption2)
                .foregroundStyle(JournalTheme.inkSoft.opacity(0.85))
                .fixedSize(horizontal: false, vertical: true)
        }
        .task {
            guard startsTalking else { return }
            reviewBeforeSave = true
            await dictation.begin(onSettled: appendSpoken, onLive: { _ in }, onRewrite: replaceSpoken)
        }
        .onDisappear {
            Task { await dictation.finishTalking() }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active {
                Task { await dictation.finishTalking() }
            }
        }
    }

    private var caption: String {
        if let note = dictation.note { return note }
        if dictation.isListening {
            return "Listening in English."
        }
        if reviewBeforeSave { return "Edit anything that doesn’t sound like you, then keep the entry." }
        return "Talk, and the page fills in while you speak."
    }

    private func appendSpoken(_ piece: String) {
        let trimmed = piece.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if spoken.isEmpty {
            spokenBaseline = content
        }
        spoken = DictationTranscript.join(base: spoken, spoken: trimmed)
        content = DictationTranscript.join(base: spokenBaseline, spoken: spoken)
    }

    private func replaceSpoken(_ full: String) {
        let trimmed = full.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let current = DictationTranscript.join(base: spokenBaseline, spoken: spoken)
        guard content.trimmingCharacters(in: .whitespacesAndNewlines) == current.trimmingCharacters(in: .whitespacesAndNewlines) else { return }
        spoken = trimmed
        content = DictationTranscript.join(base: spokenBaseline, spoken: trimmed)
    }
}

private struct WritingSurface: View {
    @Binding var content: String
    var livePhrase: String
    var isListening: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topLeading) {
                if content.isEmpty && livePhrase.isEmpty {
                    Text(isListening ? "Start talking…" : "Start writing…")
                        .foregroundStyle(JournalTheme.inkSoft.opacity(0.75))
                        .padding(.top, 8)
                        .padding(.leading, 5)
                        .allowsHitTesting(false)
                }
                TextEditor(text: $content)
                    .font(.body)
                    .foregroundStyle(JournalTheme.ink)
                    .scrollContentBackground(.hidden)
                    .frame(minHeight: 220)
            }
            if !livePhrase.isEmpty {
                Text(livePhrase)
                    .font(.body.italic())
                    .foregroundStyle(JournalTheme.accent)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .accessibilityLabel("Hearing \(livePhrase)")
            }
        }
    }
}
