import SwiftUI
import SwiftData

struct MeView: View {
    @AppStorage("displayName") private var displayName = "Aaradhana"
    @Query(
        filter: #Predicate<JournalEntry> { $0.isPrivate == false },
        sort: \JournalEntry.createdAt,
        order: .reverse
    )
    private var entries: [JournalEntry]
    @Query(sort: \StoryPiece.createdAt, order: .reverse)
    private var pieces: [StoryPiece]
    @State private var year = Calendar.current.component(.year, from: .now)

    private var portrait: StoryYear.Portrait {
        StoryYear.portrait(
            year: year,
            entries: entries.map { StorySource(date: $0.createdAt, title: $0.title, content: $0.content, isPrivate: $0.isPrivate) },
            memories: pieces.map(\.createdAt)
        )
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    header
                    stats
                    ForEach(StoryShelf.allCases) { shelf in
                        shelfSection(shelf)
                    }
                }
                .padding(24)
            }
            .background(JournalBackground())
            .navigationTitle("Me")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        SettingsView()
                    } label: {
                        Image(systemName: "gearshape")
                    }
                    .buttonStyle(GlassIconButtonStyle())
                    .accessibilityLabel("Settings")
                }
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "My name" : displayName)
                .font(.system(.largeTitle, design: .serif))
                .textCase(.uppercase)
                .tracking(1.4)
                .foregroundStyle(JournalTheme.ink)
            Text("My Story")
                .font(.system(.title3, design: .serif))
                .foregroundStyle(JournalTheme.inkSoft)
            HStack {
                Button {
                    year -= 1
                } label: {
                    Image(systemName: "chevron.left")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("Previous year")
                Text(String(year))
                    .font(.system(.title2, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                    .frame(minWidth: 72)
                Button {
                    year += 1
                } label: {
                    Image(systemName: "chevron.right")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("Next year")
            }
            .padding(.top, 8)
            Rectangle()
                .fill(JournalTheme.rule)
                .frame(height: 1)
                .padding(.top, 4)
        }
    }

    private var stats: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(StoryYear.entriesLabel(portrait.entries))
            Text(StoryYear.wordsLabel(portrait.words))
            Text(StoryYear.memoriesLabel(portrait.memories))
        }
        .font(.body)
        .foregroundStyle(JournalTheme.ink)
    }

    private func shelfSection(_ shelf: StoryShelf) -> some View {
        let written = pieces.filter { $0.kind == shelf && Calendar.current.component(.year, from: $0.createdAt) == year }
        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(shelf.rawValue)
                    .font(.system(.subheadline, design: .serif))
                    .tracking(1.1)
                    .textCase(.uppercase)
                    .foregroundStyle(JournalTheme.inkSoft)
                Spacer()
                NavigationLink {
                    StoryEditor(shelf: shelf)
                } label: {
                    Image(systemName: "plus")
                }
                .buttonStyle(GlassIconButtonStyle())
                .accessibilityLabel("Add to \(shelf.rawValue)")
            }
            if shelf == .chapter {
                ForEach(portrait.months, id: \.self) { month in
                    NavigationLink {
                        MonthChapterView(month: month, entries: entries.filter { Calendar.current.isDate($0.createdAt, equalTo: month, toGranularity: .month) })
                    } label: {
                        storyRow(month.formatted(.dateTime.month(.wide)))
                    }
                    .buttonStyle(.plain)
                }
            }
            if written.isEmpty && (shelf != .chapter || portrait.months.isEmpty) {
                Text(shelf.prompt)
                    .font(.body)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
            ForEach(written) { piece in
                NavigationLink {
                    StoryEditor(shelf: shelf, existing: piece)
                } label: {
                    storyRow(piece.title.isEmpty ? "Untitled" : piece.title)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private func storyRow(_ title: String) -> some View {
        HStack {
            Text(title)
                .font(.system(.body, design: .serif))
                .foregroundStyle(JournalTheme.ink)
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(JournalTheme.inkSoft)
        }
        .padding(.vertical, 6)
    }
}

private struct MonthChapterView: View {
    var month: Date
    var entries: [JournalEntry]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Text(month.formatted(.dateTime.month(.wide).year()))
                    .font(.system(.title3, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                    .padding(.bottom, 12)
                if entries.isEmpty {
                    EmptyNote(title: "A quiet month", message: "Nothing from the journal lives here.")
                } else {
                    ForEach(entries) { entry in
                        NavigationLink {
                            JournalEntryView(entry: entry, allowsPrivateContent: false)
                        } label: {
                            EntryRow(title: entry.title, content: entry.content, date: entry.createdAt)
                        }
                        .buttonStyle(.plain)
                        Divider().overlay(JournalTheme.rule)
                    }
                }
            }
            .padding(24)
        }
        .background(JournalBackground())
        .navigationTitle("Chapter")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct StoryEditor: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    var shelf: StoryShelf
    var existing: StoryPiece?

    @State private var title = ""
    @State private var bodyText = ""
    @State private var confirmDelete = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                TextField("Title", text: $title)
                    .font(.system(.title2, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                ZStack(alignment: .topLeading) {
                    if bodyText.isEmpty {
                        Text(shelf.prompt)
                            .foregroundStyle(JournalTheme.inkSoft.opacity(0.75))
                            .padding(.top, 8)
                            .padding(.leading, 5)
                            .allowsHitTesting(false)
                    }
                    TextEditor(text: $bodyText)
                        .font(.body)
                        .foregroundStyle(JournalTheme.ink)
                        .scrollContentBackground(.hidden)
                        .frame(minHeight: 220)
                }
                if existing != nil {
                    Button("Remove", role: .destructive) { confirmDelete = true }
                        .font(.body)
                        .padding(.top, 8)
                }
            }
            .padding(24)
        }
        .background(JournalBackground())
        .navigationTitle(shelf.rawValue)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Keep") {
                    save()
                    dismiss()
                }
                .font(.body.weight(.medium))
                .foregroundStyle(JournalTheme.ink)
            }
        }
        .onAppear {
            title = existing?.title ?? ""
            bodyText = existing?.body ?? ""
        }
        .confirmationDialog("Remove this from My Story?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Remove", role: .destructive) {
                if let existing {
                    context.delete(existing)
                    try? context.save()
                }
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        }
    }

    private func save() {
        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedBody = bodyText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTitle.isEmpty || !trimmedBody.isEmpty else { return }
        let piece = existing ?? StoryPiece(shelf: shelf)
        if existing == nil {
            context.insert(piece)
        }
        piece.title = title
        piece.body = bodyText
        piece.updatedAt = .now
        try? context.save()
    }
}
