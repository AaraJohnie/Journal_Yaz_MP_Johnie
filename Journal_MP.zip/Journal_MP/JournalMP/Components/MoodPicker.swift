import SwiftUI

struct MoodPicker: View {
    @Binding var mood: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                ForEach(Mood.allCases) { item in
                    let selected = Mood.resolved(mood) == item
                    Button {
                        mood = selected ? nil : item.rawValue
                    } label: {
                        Text(item.symbol)
                            .font(.title3)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background { GlassSurface(isSelected: selected) }
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(item.rawValue)
                    .accessibilityAddTraits(selected ? .isSelected : [])
                }
            }
            if let match = Mood.resolved(mood) {
                Text(match.rawValue)
                    .font(.footnote)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
        }
    }
}
