import SwiftUI

struct JournalBackground: View {
    var body: some View {
        ZStack {
            JournalTheme.paper
            Circle()
                .fill(JournalTheme.blushPink.opacity(0.45))
                .frame(width: 280, height: 280)
                .blur(radius: 70)
                .offset(x: 130, y: -240)
            Circle()
                .fill(JournalTheme.blushGold.opacity(0.40))
                .frame(width: 320, height: 320)
                .blur(radius: 80)
                .offset(x: -140, y: 260)
        }
        .ignoresSafeArea()
    }
}

struct GlassSurface: View {
    var isSelected: Bool = false

    var body: some View {
        Capsule()
            .fill(.ultraThinMaterial)
            .overlay {
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [
                                JournalTheme.blushPink.opacity(isSelected ? 0.62 : 0.42),
                                JournalTheme.blushGold.opacity(isSelected ? 0.50 : 0.28),
                                Color.white.opacity(0.18)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }
            .overlay {
                Capsule()
                    .strokeBorder(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(0.9),
                                JournalTheme.blushGold.opacity(0.95),
                                JournalTheme.blushPink.opacity(0.55)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1
                    )
            }
            .shadow(color: JournalTheme.blushPink.opacity(0.28), radius: 14, y: 8)
            .shadow(color: JournalTheme.blushGold.opacity(0.18), radius: 6, y: 2)
    }
}

struct JournalButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.medium))
            .foregroundStyle(JournalTheme.ink)
            .padding(.horizontal, 22)
            .padding(.vertical, 14)
            .background { GlassSurface() }
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
    }
}

struct GlassIconButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.medium))
            .foregroundStyle(JournalTheme.ink)
            .frame(width: 36, height: 36)
            .background { GlassSurface() }
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
    }
}
