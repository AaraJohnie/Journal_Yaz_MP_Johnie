import SwiftUI

struct EntryCard: View {
    let title: String
    let content: String
    let mood: String?
    let date: Date
    var showsTime: Bool = true

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text(title)
                    .font(.system(.title3, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
            }
            Text(JournalVisibility.excerpt(content, fallback: title))
                .font(.body)
                .foregroundStyle(JournalTheme.inkSoft)
                .lineLimit(4)
                .frame(maxWidth: .infinity, alignment: .leading)
            HStack(spacing: 8) {
                if let mood, !mood.isEmpty {
                    Text(moodLabel(mood))
                        .font(.footnote)
                        .foregroundStyle(JournalTheme.ink)
                }
                Spacer()
                Text(showsTime ? date.formatted(date: .omitted, time: .shortened) : date.formatted(date: .abbreviated, time: .omitted))
                    .font(.footnote)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(JournalTheme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(JournalTheme.rule, lineWidth: 1)
        }
    }

    private func moodLabel(_ mood: String) -> String {
        if let match = Mood.resolved(mood) {
            return "\(match.symbol) \(match.rawValue)"
        }
        return mood
    }
}

struct EntryRow: View {
    let title: String
    let content: String
    let date: Date

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(date.formatted(.dateTime.weekday(.abbreviated).month(.abbreviated).day()))
                .font(.caption)
                .foregroundStyle(JournalTheme.inkSoft)
            Text(rowTitle)
                .font(.system(.body, design: .serif))
                .foregroundStyle(JournalTheme.ink)
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 8)
    }

    private var rowTitle: String {
        let heading = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !heading.isEmpty { return heading }
        let preview = JournalVisibility.excerpt(content, limit: 80)
        return preview.isEmpty ? "Untitled" : preview
    }
}

struct EmptyNote: View {
    let title: String
    let message: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(.title3, design: .serif))
                .foregroundStyle(JournalTheme.ink)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(JournalTheme.inkSoft)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
