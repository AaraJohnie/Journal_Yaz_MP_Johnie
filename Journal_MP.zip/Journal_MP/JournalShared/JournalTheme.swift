import SwiftUI
import UIKit

enum JournalAppearance: String, CaseIterable, Identifiable {
    case light
    case dark

    var id: String { rawValue }

    var title: String {
        switch self {
        case .light: "Light"
        case .dark: "Dark"
        }
    }

    var symbol: String {
        switch self {
        case .light: "sun.max"
        case .dark: "moon"
        }
    }

    var scheme: ColorScheme {
        switch self {
        case .light: .light
        case .dark: .dark
        }
    }

    static func stored(_ raw: String) -> JournalAppearance {
        JournalAppearance(rawValue: raw) ?? .light
    }
}

enum JournalTheme {
    static let paper = dynamic(
        light: UIColor(red: 0.965, green: 0.949, blue: 0.925, alpha: 1),
        dark: UIColor(red: 0.09, green: 0.08, blue: 0.07, alpha: 1)
    )
    static let card = dynamic(
        light: UIColor(red: 0.992, green: 0.984, blue: 0.969, alpha: 1),
        dark: UIColor(red: 0.14, green: 0.13, blue: 0.12, alpha: 1)
    )
    static let ink = dynamic(
        light: UIColor(red: 0.16, green: 0.13, blue: 0.11, alpha: 1),
        dark: UIColor(red: 0.95, green: 0.93, blue: 0.89, alpha: 1)
    )
    static let inkSoft = dynamic(
        light: UIColor(red: 0.42, green: 0.37, blue: 0.33, alpha: 1),
        dark: UIColor(red: 0.72, green: 0.68, blue: 0.62, alpha: 1)
    )
    static let rule = dynamic(
        light: UIColor(red: 0.86, green: 0.82, blue: 0.76, alpha: 1),
        dark: UIColor(red: 0.28, green: 0.25, blue: 0.22, alpha: 1)
    )
    static let accent = dynamic(
        light: UIColor(red: 0.72, green: 0.38, blue: 0.46, alpha: 1),
        dark: UIColor(red: 0.93, green: 0.72, blue: 0.76, alpha: 1)
    )
    static let blushPink = dynamic(
        light: UIColor(red: 0.93, green: 0.62, blue: 0.70, alpha: 1),
        dark: UIColor(red: 0.78, green: 0.40, blue: 0.52, alpha: 1)
    )
    static let blushGold = dynamic(
        light: UIColor(red: 0.86, green: 0.70, blue: 0.40, alpha: 1),
        dark: UIColor(red: 0.82, green: 0.66, blue: 0.38, alpha: 1)
    )

    private static func dynamic(light: UIColor, dark: UIColor) -> Color {
        Color(uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark ? dark : light
        })
    }
}
