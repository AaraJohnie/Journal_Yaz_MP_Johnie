import Foundation

enum DictationTranscript {
    static func join(base: String, spoken: String) -> String {
        guard !spoken.isEmpty else { return base }
        guard !base.isEmpty else { return spoken }
        if base.last?.isWhitespace == true || spoken.first?.isWhitespace == true {
            return base + spoken
        }
        return base + " " + spoken
    }

    static func spoken(finalized: String, volatile: String) -> String {
        join(base: finalized, spoken: volatile)
    }

    static func suffix(after existing: String, in updated: String) -> String {
        guard updated.hasPrefix(existing) else { return updated.trimmingCharacters(in: .whitespacesAndNewlines) }
        return String(updated.dropFirst(existing.count)).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func absorb(finalized: inout String, volatile: inout String, text: String, isFinal: Bool) {
        if isFinal {
            finalized = join(base: finalized, spoken: text)
            volatile = ""
        } else {
            volatile = text
        }
    }
}
