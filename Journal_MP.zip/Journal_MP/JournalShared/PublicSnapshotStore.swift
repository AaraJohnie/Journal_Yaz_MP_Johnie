import Foundation

enum AppGroup {
    static let id = "group.com.journalmp.app"
}

enum PublicSnapshotStore {
    static let fileName = "public-snapshot.json"

    static func save(_ snapshot: PublicWidgetSnapshot) {
        guard let url = fileURL else { return }
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(snapshot) else { return }
        try? data.write(to: url, options: .atomic)
    }

    static func load() -> PublicWidgetSnapshot? {
        guard let url = fileURL, let data = try? Data(contentsOf: url) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(PublicWidgetSnapshot.self, from: data)
    }

    static func loadOrPrompt(now: Date = .now) -> PublicWidgetSnapshot {
        load() ?? PublicWidgetSnapshot(
            excerpt: "",
            title: "",
            mood: nil,
            date: now,
            prompt: DailyPrompt.forDate(now)
        )
    }

    private static var fileURL: URL? {
        FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: AppGroup.id)?
            .appendingPathComponent(fileName)
    }
}
