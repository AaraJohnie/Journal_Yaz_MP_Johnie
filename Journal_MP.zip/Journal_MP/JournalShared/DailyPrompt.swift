import Foundation

enum DailyPrompt {
    static let prompts = [
        "What is one thing you'd like to remember about today?",
        "What stayed with you from yesterday?",
        "What made you smile today?",
        "What felt heavier than it needed to?",
        "Where did you feel most like yourself?",
        "What are you grateful you noticed?",
        "What would you like tomorrow to know?",
        "What did you almost not write down?"
    ]

    static func forDate(_ date: Date, calendar: Calendar = .current) -> String {
        let day = calendar.ordinality(of: .day, in: .year, for: date) ?? 1
        return prompts[(day - 1) % prompts.count]
    }
}
