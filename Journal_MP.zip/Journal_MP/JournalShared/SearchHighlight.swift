import Foundation

enum SearchHighlight {
    enum Focus: Equatable {
        case title
        case paragraph(Int)
    }

    static func ranges(in text: String, query: String) -> [Range<String.Index>] {
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !needle.isEmpty, !text.isEmpty else { return [] }
        var found: [Range<String.Index>] = []
        var start = text.startIndex
        while start < text.endIndex,
              let range = text.range(
                of: needle,
                options: [.caseInsensitive, .diacriticInsensitive],
                range: start..<text.endIndex,
                locale: .current
              ) {
            found.append(range)
            if range.upperBound == start { break }
            start = range.upperBound
        }
        return found
    }

    static func focus(title: String, content: String, query: String) -> Focus? {
        if !ranges(in: title, query: query).isEmpty { return .title }
        let paragraphs = content.components(separatedBy: "\n")
        for (index, paragraph) in paragraphs.enumerated() where !ranges(in: paragraph, query: query).isEmpty {
            return .paragraph(index)
        }
        return nil
    }
}
