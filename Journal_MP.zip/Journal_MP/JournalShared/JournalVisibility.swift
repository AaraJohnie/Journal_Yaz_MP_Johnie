import Foundation

struct VisibleEntry: Equatable {
    var title: String
    var content: String
    var createdAt: Date
    var mood: String?
    var isFavorite: Bool
    var isPrivate: Bool
}

struct PublicWidgetSnapshot: Codable, Equatable {
    var excerpt: String
    var title: String
    var mood: String?
    var date: Date
    var prompt: String
}

enum JournalVisibility {
    static func publicEntries(_ entries: [VisibleEntry]) -> [VisibleEntry] {
        entries.filter { !$0.isPrivate }
    }

    static func search(_ entries: [VisibleEntry], query: String) -> [VisibleEntry] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }
        return entries.filter { entry in
            guard !entry.isPrivate else { return false }
            return entry.title.localizedStandardContains(trimmed)
                || entry.content.localizedStandardContains(trimmed)
        }
    }

    static func excerpt(_ text: String, fallback: String = "", limit: Int = 140) -> String {
        let primary = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let source = (primary.isEmpty ? fallback : primary)
            .replacingOccurrences(of: "\n", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard source.count > limit else { return source }
        let end = source.index(source.startIndex, offsetBy: limit)
        return source[..<end].trimmingCharacters(in: .whitespacesAndNewlines) + "…"
    }

    /// The widget snapshot is built only from entries that are not private.
    static func widgetSnapshot(from entries: [VisibleEntry], prompt: String, now: Date = .now) -> PublicWidgetSnapshot {
        let latest = publicEntries(entries)
            .filter { entry in
                !entry.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    || !entry.content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            }
            .max { $0.createdAt < $1.createdAt }

        guard let latest else {
            return PublicWidgetSnapshot(excerpt: "", title: "", mood: nil, date: now, prompt: prompt)
        }

        return PublicWidgetSnapshot(
            excerpt: excerpt(latest.content, fallback: latest.title),
            title: latest.title.trimmingCharacters(in: .whitespacesAndNewlines),
            mood: latest.mood,
            date: latest.createdAt,
            prompt: prompt
        )
    }

    static func exportText(from entries: [VisibleEntry]) -> String {
        let visible = publicEntries(entries).sorted { $0.createdAt > $1.createdAt }
        guard !visible.isEmpty else { return "Your journal is empty." }
        return visible.map { entry in
            let date = entry.createdAt.formatted(date: .complete, time: .shortened)
            let heading = entry.title.trimmingCharacters(in: .whitespacesAndNewlines)
            let mood = entry.mood.map { "\n\($0)" } ?? ""
            let body = entry.content.trimmingCharacters(in: .whitespacesAndNewlines)
            return ([date, heading].filter { !$0.isEmpty }.joined(separator: "\n") + mood + "\n\n" + body)
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        .joined(separator: "\n\n———\n\n")
    }
}
