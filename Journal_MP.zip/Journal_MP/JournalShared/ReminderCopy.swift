import Foundation

/// Reminder text is fixed. It never accepts an entry, so private writing cannot reach a notification.
enum ReminderCopy {
    static let identifier = "journal.daily.reminder"
    static let title = "Journal"
    static let body = "A quiet moment to write."
}
