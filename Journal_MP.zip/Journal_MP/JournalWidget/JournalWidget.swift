import WidgetKit
import SwiftUI

struct JournalWidgetEntry: TimelineEntry {
    let date: Date
    let snapshot: PublicWidgetSnapshot
}

struct JournalProvider: TimelineProvider {
    func placeholder(in context: Context) -> JournalWidgetEntry {
        JournalWidgetEntry(date: .now, snapshot: PublicSnapshotStore.loadOrPrompt())
    }

    func getSnapshot(in context: Context, completion: @escaping (JournalWidgetEntry) -> Void) {
        completion(JournalWidgetEntry(date: .now, snapshot: PublicSnapshotStore.loadOrPrompt()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<JournalWidgetEntry>) -> Void) {
        let entry = JournalWidgetEntry(date: .now, snapshot: PublicSnapshotStore.loadOrPrompt())
        let next = Calendar.current.date(byAdding: .hour, value: 1, to: .now) ?? .now.addingTimeInterval(3600)
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
}

struct JournalWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: JournalWidgetEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Journal")
                .font(.caption.weight(.medium))
                .foregroundStyle(JournalTheme.inkSoft)
            if entry.snapshot.excerpt.isEmpty {
                Text(entry.snapshot.prompt)
                    .font(.system(.callout, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
            } else {
                if !entry.snapshot.title.isEmpty {
                    Text(entry.snapshot.title)
                        .font(.system(.headline, design: .serif))
                        .foregroundStyle(JournalTheme.ink)
                        .lineLimit(1)
                }
                Text(entry.snapshot.excerpt)
                    .font(.system(.callout, design: .serif))
                    .foregroundStyle(JournalTheme.ink)
                    .lineLimit(family == .systemSmall ? 4 : 3)
                    .privacySensitive()
                Spacer(minLength: 0)
                Text(entry.snapshot.date.formatted(date: .abbreviated, time: .omitted))
                    .font(.caption2)
                    .foregroundStyle(JournalTheme.inkSoft)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct JournalEntryWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "JournalEntry", provider: JournalProvider()) { entry in
            JournalWidgetView(entry: entry)
                .containerBackground(JournalTheme.paper, for: .widget)
        }
        .configurationDisplayName("Journal")
        .description("A glimpse of your latest entry. Private entries stay hidden.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

@main
struct JournalWidgetBundle: WidgetBundle {
    var body: some Widget {
        JournalEntryWidget()
    }
}
